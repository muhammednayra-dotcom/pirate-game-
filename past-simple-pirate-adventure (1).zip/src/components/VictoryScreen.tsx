import { Fragment } from "react";
import { ISLANDS } from "../game/data";
import type { HighScore } from "../game/highscores";
import { Coin, Key, PirateKid, PirateShip, Star, TreasureChest } from "./Illustrations";
import Certificate from "./Certificate";
import { Confetti, Logo, RestartIcon } from "./UI";

interface Props {
  name: string;
  score: number;
  coins: number;
  keys: number;
  correct: number;
  firstTry: number;
  highScores: HighScore[];
  onRestart: () => void;
  onHome: () => void;
}

export default function VictoryScreen({ name, score, coins, keys, correct, firstTry, highScores, onRestart, onHome }: Props) {
  const pirate = name.trim() || "Little Pirate";
  return (
    <div className="relative min-h-[100dvh] overflow-hidden bg-[linear-gradient(180deg,#8BE8EC_0%,#CFF8E8_34%,#FFE9B0_78%,#FFD98A_100%)] px-3 pb-8 pt-3 sm:px-6 sm:pt-5">
      <Confetti pieces={56} />
      <div className="pointer-events-none absolute -right-16 top-20 h-64 w-64 rounded-full bg-[#FFE07A] opacity-50 blur-3xl" aria-hidden="true" />

      <div className="relative mx-auto w-full max-w-5xl">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="rounded-2xl bg-[#073b4c]/95 px-2.5 py-2 shadow-lg sm:rounded-3xl sm:px-4 sm:py-2.5">
            <Logo compact />
          </div>
          <button type="button" onClick={onHome} className="btn btn-ghost !px-3 !py-2 !text-xs sm:!px-4 sm:!text-sm">🏠 Start screen</button>
        </div>

        <div className="mt-4 text-center">
          <span className="inline-flex items-center gap-1.5 rounded-full border-2 border-[#0c6b73]/20 bg-white/80 px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.24em] text-[#0c6b73] sm:text-xs">
            ✨ Quest complete · all 10 islands ✨
          </span>
          <h1 className="mx-auto mt-2 max-w-3xl break-words font-display text-[1.9rem] font-extrabold leading-[0.95] tracking-tight text-[#073b4c] sm:text-5xl lg:text-6xl">
            CONGRATULATIONS,{" "}
            <span className="text-[#b87505]">{pirate.toUpperCase()}!</span>
            <br />
            <span className="text-[#0c6b73]">YOU MASTERED THE PAST SIMPLE!</span>
          </h1>
          <p className="mx-auto mt-2 max-w-lg text-sm font-bold text-[#356b72] sm:text-base">
            Ten islands, fifty clues and one legendary treasure. You are officially a Past Simple Pirate Champion! 🏴‍☠️
          </p>
        </div>

        <div className="relative mt-3 overflow-hidden rounded-3xl border-[3px] border-[#f4cd72] bg-[linear-gradient(180deg,#bff3ee,#ffe3a8)] shadow-[0_24px_50px_-18px_rgba(0,40,50,0.6)]">
          <div className="absolute inset-0" aria-hidden="true">
            <div className="absolute left-1/2 top-1/2 h-56 w-56 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#FFF3B8] opacity-80 blur-2xl" />
          </div>
          <div className="relative flex flex-col items-center px-3 py-4 sm:py-6">
            <TreasureChest open className="key-float h-32 w-32 drop-shadow-[0_18px_18px_rgba(120,70,0,0.3)] sm:h-44 sm:w-44" />
            <div className="mt-1 flex flex-wrap items-center justify-center gap-1.5">
              {ISLANDS.map((island) => (
                <span key={island.id} className="grid h-6 w-6 place-items-center rounded-full bg-[#f5b51b] text-[11px] shadow-[0_2px_0_#b87505]" title={`${island.name} — unlocked`}>
                  🔑
                </span>
              ))}
            </div>
            <p className="mt-1.5 font-display text-sm font-extrabold uppercase tracking-[0.12em] text-[#7a5200]">All 10 golden keys collected!</p>
            <PirateKid className="float-slow pointer-events-none absolute -bottom-2 left-1 h-24 w-auto sm:-bottom-3 sm:left-4 sm:h-32" waving />
            <div className="sail-in pointer-events-none absolute bottom-3 right-3 opacity-90 sm:bottom-5 sm:right-6">
              <PirateShip className="ship-rock h-14 w-14 sm:h-20 sm:w-20" />
            </div>
            <div className="pointer-events-none absolute right-4 top-3 hidden items-center gap-1 rounded-lg bg-white/85 px-2 py-1 text-[10px] font-extrabold text-[#07505c] shadow sm:flex">
              <Coin className="h-4 w-4" /> +{coins} coins
            </div>
          </div>
        </div>

        <div className="mt-4 grid gap-3 lg:grid-cols-[1fr_1.02fr]">
          <div className="rounded-2xl border-2 border-[#f0d9aa] bg-[#073b4c]/95 p-3 text-white shadow-xl sm:p-4">
            <h2 className="font-display text-lg font-extrabold text-[#ffe9a8] sm:text-xl">Your champion stats</h2>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {[
                { label: "Total score", value: score, icon: <Star className="h-5 w-5 text-[#ffd76b]" /> },
                { label: "Gold coins", value: coins, icon: <Coin className="h-5 w-5" /> },
                { label: "Golden keys", value: `${keys}/10`, icon: <Key className="h-5 w-5" /> },
                { label: "Clues answered", value: `${correct}/50`, icon: <span className="text-base">🧩</span> },
              ].map((stat) => (
                <div key={stat.label} className="flex items-center gap-2 rounded-xl border border-white/15 bg-white/10 px-2.5 py-2">
                  {stat.icon}
                  <div>
                    <p className="font-display text-xl font-extrabold leading-none">{stat.value}</p>
                    <p className="text-[9px] font-extrabold uppercase tracking-wider text-white/60">{stat.label}</p>
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-2 rounded-xl bg-[#f5b51b]/15 px-2.5 py-2 text-[11px] font-bold leading-snug text-[#ffe9a8]">
              {firstTry} clues were correct on the very first try. {firstTry >= 42 ? "A truly legendary pirate brain!" : "What a brilliant voyage — your grammar treasure is full!"}
            </p>

            <h3 className="mt-3 font-display text-sm font-extrabold uppercase tracking-widest text-[#ffe9a8]">🏆 Pirate hall of fame</h3>
            {highScores.length === 0 ? (
              <p className="mt-1 text-xs font-bold text-white/60">Your score is being inked into the captain's log…</p>
            ) : (
              <ol className="mt-1.5 space-y-1">
                {highScores.slice(0, 5).map((entry, index) => (
                  <li key={`${entry.name}-${entry.date}-${index}`} className={`flex items-center gap-2 rounded-lg px-2 py-1.5 text-[11px] sm:text-xs ${index === 0 ? "bg-[#f5b51b]/20" : "bg-white/10"}`}>
                    <span className="w-4 text-center">{["🥇", "🥈", "🥉"][index] ?? `${index + 1}.`}</span>
                    <span className="min-w-0 flex-1 truncate font-display font-extrabold">{entry.name}</span>
                    <span className="text-white/55">{entry.keys}/10 🗝️</span>
                    <span className="flex items-center gap-0.5 font-extrabold text-[#ffe9a8]"><Star className="h-3 w-3" /> {entry.score}</span>
                  </li>
                ))}
              </ol>
            )}

            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              <button type="button" onClick={onRestart} className="btn btn-primary !py-2.5 !text-sm">
                <RestartIcon className="h-4 w-4" /> Play again
              </button>
              <button type="button" onClick={onHome} className="btn btn-teal !py-2.5 !text-sm">🏠 Start screen</button>
            </div>
          </div>

          <div>
            <Certificate name={pirate} score={score} coins={coins} keys={keys} />
            <p className="mt-2 text-center text-[10px] font-bold text-[#356b72]">Save it, print it, or stick it on the fridge, champion! 🧲</p>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-center gap-1 text-center">
          {ISLANDS.map((island, index) => (
            <Fragment key={island.id}>
              <span className="rounded-full bg-white/75 px-2 py-1 text-[9px] font-extrabold text-[#07505c] sm:text-[10px]" title={island.tagline}>{island.icon} {island.name}</span>
              {index < ISLANDS.length - 1 && <span className="text-[#0c6b73]/40">·</span>}
            </Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}
