import { useEffect, useState } from "react";
import { ISLANDS, type Island } from "../game/data";
import type { HighScore } from "../game/highscores";
import { Coin, Key, Parrot, PirateShip, Star } from "./Illustrations";
import { CloseIcon, Confetti, RestartIcon, SoundOffIcon, SoundOnIcon } from "./UI";

export function PauseOverlay({
  islandName,
  coins,
  keys,
  score,
  muted,
  onResume,
  onRestart,
  onEnd,
  onToggleSound,
}: {
  islandName: string;
  coins: number;
  keys: number;
  score: number;
  muted: boolean;
  onResume: () => void;
  onRestart: () => void;
  onEnd: () => void;
  onToggleSound: () => void;
}) {
  const [confirmRestart, setConfirmRestart] = useState(false);
  const [showHelp, setShowHelp] = useState(false);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape" || event.key === "Enter") {
        event.preventDefault();
        if (confirmRestart) setConfirmRestart(false);
        else onResume();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onResume, confirmRestart]);

  return (
    <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-[#032d3a]/75 p-3 backdrop-blur-md sm:p-6" role="dialog" aria-modal="true" aria-labelledby="pause-title">
      <div className="feedback-rise w-full max-w-md rounded-3xl border-[3px] border-[#f0d9aa] bg-[linear-gradient(180deg,#fffdf6,#fff4dd)] p-4 shadow-[0_30px_70px_-20px_rgba(0,0,0,0.7)] sm:p-6">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-[10px] font-extrabold uppercase tracking-[0.22em] text-[#0c6b73]">Anchor down</p>
            <h2 id="pause-title" className="font-display text-3xl font-extrabold leading-none text-[#073b4c] sm:text-4xl">Paused, matey! 🦜</h2>
            <p className="mt-1 text-xs font-bold text-[#54747d]">Resting at {islandName}. The treasure can wait!</p>
          </div>
          <button type="button" onClick={onResume} className="icon-btn shrink-0 !border-[#d9e6e8] !bg-white !text-[#0c6b73]" aria-label="Resume game">
            <CloseIcon />
          </button>
        </div>

        <div className="mt-3 grid grid-cols-3 gap-2">
          {[
            { icon: <Coin className="h-5 w-5" />, value: coins, label: "Coins" },
            { icon: <Key className="h-5 w-5" />, value: `${keys}/10`, label: "Keys" },
            { icon: <Star className="h-5 w-5 text-[#f5b51b]" />, value: score, label: "Score" },
          ].map((stat) => (
            <div key={stat.label} className="flex flex-col items-center gap-1 rounded-xl border-2 border-[#eadfc4] bg-white px-2 py-2 text-center">
              <span>{stat.icon}</span>
              <span className="font-display text-lg font-extrabold leading-none text-[#073b4c]">{stat.value}</span>
              <span className="text-[9px] font-extrabold uppercase tracking-wider text-[#8a7638]">{stat.label}</span>
            </div>
          ))}
        </div>

        <div className="mt-3 space-y-2">
          <button type="button" onClick={onResume} className="btn btn-primary w-full !py-3 !text-base">
            ▶ Resume adventure
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={onToggleSound} className="btn btn-ghost !py-2.5 !text-xs sm:!text-sm">
              {muted ? <SoundOffIcon className="h-4 w-4" /> : <SoundOnIcon className="h-4 w-4" />} Sound {muted ? "off" : "on"}
            </button>
            <button type="button" onClick={() => setShowHelp((prev) => !prev)} className="btn btn-ghost !py-2.5 !text-xs sm:!text-sm">
              📖 How to play
            </button>
          </div>
          {showHelp && (
            <div className="feedback-rise rounded-xl border-2 border-[#e6f0f0] bg-[#f4fbfb] p-2.5 text-[11px] font-semibold leading-snug text-[#3f6875]">
              Answer each clue. Correct answers earn coins; if you miss, try again — you never lose progress. Five correct clues unlock the island key. Numbers pick answers, Enter moves on, Esc pauses.
            </div>
          )}
          {confirmRestart ? (
            <div className="feedback-rise rounded-xl border-2 border-[#f2c3b7] bg-[#fff3ee] p-2.5">
              <p className="text-xs font-extrabold text-[#9a3b22]">Start a brand-new voyage? This run will end.</p>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <button type="button" onClick={onRestart} className="btn btn-coral !py-2 !text-xs sm:!text-sm">Yes, sail again</button>
                <button type="button" onClick={() => setConfirmRestart(false)} className="btn btn-ghost !py-2 !text-xs sm:!text-sm">Keep playing</button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              <button type="button" onClick={() => setConfirmRestart(true)} className="btn btn-ghost !py-2.5 !text-xs sm:!text-sm">
                <RestartIcon className="h-4 w-4" /> Restart
              </button>
              <button type="button" onClick={onEnd} className="btn btn-ghost !py-2.5 !text-xs !text-[#a4521f] sm:!text-sm">
                🏁 End voyage
              </button>
            </div>
          )}
        </div>
        <p className="mt-2 hidden text-center text-[10px] font-bold text-[#8a7638] sm:block">Press Esc or Enter to keep sailing</p>
      </div>
    </div>
  );
}

export function IslandClearOverlay({
  island,
  keys,
  isLast,
  onContinue,
}: {
  island: Island;
  keys: number;
  isLast: boolean;
  onContinue: () => void;
}) {
  useEffect(() => {
    const timer = window.setTimeout(onContinue, 5200);
    return () => window.clearTimeout(timer);
  }, [onContinue]);

  const nextIsland = ISLANDS[island.id];
  return (
    <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-[#032d3a]/70 p-3 backdrop-blur-sm sm:p-6" role="dialog" aria-modal="true" aria-labelledby="key-title">
      <Confetti pieces={28} />
      <div className="feedback-rise relative w-full max-w-lg overflow-hidden rounded-3xl border-[3px] border-[#f2d287] bg-[linear-gradient(180deg,#fffdf6,#fff2d5)] p-4 text-center shadow-[0_30px_70px_-20px_rgba(0,0,0,0.7)] sm:p-6">
        <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-[#ffe07a]/60 blur-xl" />
        <div className="relative mx-auto grid h-24 w-24 place-items-center sm:h-28 sm:w-28">
          <span className="absolute inset-0 animate-ping rounded-full bg-[#ffe07a]/40" />
          <Key className="key-float relative h-24 w-24 drop-shadow-[0_8px_10px_rgba(150,100,0,0.35)] sm:h-28 sm:w-28" />
        </div>
        <p className="mt-1 text-[10px] font-extrabold uppercase tracking-[0.3em] text-[#0c6b73] sm:text-xs">{isLast ? "The final key!" : `Golden key ${keys} of 10`}</p>
        <h2 id="key-title" className="mt-1 font-display text-3xl font-extrabold leading-none text-[#073b4c] sm:text-4xl">
          {island.name} unlocked!
        </h2>
        <p className="mx-auto mt-2 max-w-xs text-xs font-bold text-[#54747d] sm:text-sm">
          {isLast
            ? "All ten keys are yours! The treasure chest is glowing on Treasure Isle. Let's open it!"
            : `Brilliant work, little pirate! The ship is ready to sail to ${nextIsland?.name ?? "the next island"}.`}
        </p>

        <div className="mt-3 flex items-center justify-center gap-2 rounded-2xl border-2 border-[#eadfc4] bg-white/90 px-3 py-2">
          {Array.from({ length: 10 }).map((_, index) => (
            <span
              key={index}
              className={`grid h-4 w-4 place-items-center rounded-full text-[8px] sm:h-5 sm:w-5 ${index < keys ? "bg-[#f5b51b] text-[#6b4600] shadow-[0_0_0_2px_#ffe9a8]" : "bg-[#e6e1d3]"}`}
              aria-hidden="true"
            >
              {index < keys ? "★" : ""}
            </span>
          ))}
        </div>

        <div className="mt-3 flex items-center gap-2 rounded-2xl bg-[#073b4c]/95 px-3 py-2 text-left text-white">
          <PirateShip className="ship-rock h-12 w-12 shrink-0 text-white sm:h-14 sm:w-14" />
          <div className="min-w-0">
            <p className="text-[9px] font-extrabold uppercase tracking-widest text-[#ffe9a8]">Setting sail…</p>
            <p className="truncate font-display text-sm font-extrabold sm:text-base">{isLast ? "Treasure Isle" : nextIsland?.name}</p>
          </div>
          <span className="ml-auto text-xl" aria-hidden="true">🌊</span>
        </div>

        <button type="button" onClick={onContinue} className="btn btn-primary mt-3 w-full !py-3 !text-base">
          {isLast ? "Open the treasure chest! 💎" : "Sail on, matey! ⛵"}
        </button>
        <div className="mx-auto mt-2 h-1.5 w-2/3 overflow-hidden rounded-full bg-[#073b4c]/10">
          <div className="h-full rounded-full bg-[#0c6b73]/60" style={{ animation: "countdown 5.2s linear forwards" }} />
        </div>
        <style>{`@keyframes countdown{from{width:0%}to{width:100%}}`}</style>
      </div>
    </div>
  );
}

export function VoyageEndScreen({
  name,
  score,
  coins,
  keys,
  correct,
  firstTry,
  reachedIsland,
  highScores,
  onRestart,
  onHome,
}: {
  name: string;
  score: number;
  coins: number;
  keys: number;
  correct: number;
  firstTry: number;
  reachedIsland: Island;
  highScores: HighScore[];
  onRestart: () => void;
  onHome: () => void;
}) {
  return (
    <div className="min-h-[100dvh] overflow-y-auto bg-[linear-gradient(180deg,#0e7188,#07485d_70%,#053846)] px-3 py-5 sm:px-6 sm:py-8">
      <div className="mx-auto w-full max-w-2xl">
        <div className="relative overflow-hidden rounded-3xl border-[3px] border-[#f0d9aa] bg-[linear-gradient(180deg,#fffdf6,#fff4dd)] p-4 shadow-[0_30px_70px_-20px_rgba(0,0,0,0.8)] sm:p-6">
          <div className="flex items-start gap-3">
            <Parrot className="float-slow h-16 w-16 shrink-0 sm:h-20 sm:w-20" />
            <div>
              <p className="text-[10px] font-extrabold uppercase tracking-[0.24em] text-[#0c6b73]">Voyage log</p>
              <h1 className="font-display text-3xl font-extrabold leading-none text-[#073b4c] sm:text-4xl">Anchors down, {name || "little pirate"}!</h1>
              <p className="mt-1 text-xs font-bold leading-snug text-[#54747d] sm:text-sm">
                Your crew is safe at {reachedIsland.name}. Nothing is lost — every pirate sails again! Ready for a brand-new adventure?
              </p>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {[
              { label: "Score", value: score, emoji: "⭐" },
              { label: "Coins", value: coins, emoji: "🪙" },
              { label: "Keys", value: `${keys}/10`, emoji: "🗝️" },
              { label: "Clues right", value: correct, emoji: "✅" },
            ].map((stat) => (
              <div key={stat.label} className="rounded-2xl border-2 border-[#eadfc4] bg-white px-2 py-2.5 text-center">
                <p className="text-lg" aria-hidden="true">{stat.emoji}</p>
                <p className="font-display text-xl font-extrabold leading-none text-[#073b4c] sm:text-2xl">{stat.value}</p>
                <p className="mt-1 text-[9px] font-extrabold uppercase tracking-wider text-[#8a7638]">{stat.label}</p>
              </div>
            ))}
          </div>
          <p className="mt-2 text-center text-[11px] font-bold text-[#54747d]">{firstTry} of {correct} correct answers were first try. Good sailing!</p>

          <div className="mt-4 flex flex-col gap-2 sm:flex-row">
            <button type="button" onClick={onRestart} className="btn btn-primary flex-1 !py-3 !text-base">
              ⛵ Sail again — immediate restart
            </button>
            <button type="button" onClick={onHome} className="btn btn-ghost flex-1 !py-3 !text-sm">
              🏠 Back to start
            </button>
          </div>
        </div>

        <div className="mt-3 rounded-2xl border-2 border-[#f0d9aa]/50 bg-[#073b4c]/95 p-3 text-white shadow-xl sm:p-4">
          <h2 className="font-display text-base font-extrabold text-[#ffe9a8] sm:text-lg">🏆 Pirate hall of fame</h2>
          {highScores.length === 0 ? (
            <p className="mt-2 text-xs font-bold text-white/60">No scores yet. Finish your next voyage to make history!</p>
          ) : (
            <ol className="mt-2 space-y-1">
              {highScores.map((entry, index) => (
                <li key={`${entry.name}-${entry.date}-${index}`} className={`flex items-center gap-2 rounded-lg px-2 py-1.5 text-xs ${index === 0 ? "bg-[#f5b51b]/20" : "bg-white/10"}`}>
                  <span className="w-5 text-center">{["🥇", "🥈", "🥉"][index] ?? `${index + 1}.`}</span>
                  <span className="min-w-0 flex-1 truncate font-display font-extrabold">{entry.name}</span>
                  <span className="text-white/60">{entry.coins} 🪙</span>
                  <span className="text-white/60">{entry.keys}/10 🗝️</span>
                  <span className="flex items-center gap-0.5 font-extrabold text-[#ffe9a8]"><Star className="h-3 w-3" /> {entry.score}</span>
                </li>
              ))}
            </ol>
          )}
        </div>
        <p className="mt-3 text-center text-[10px] font-semibold text-white/60">Tip: pause any time with Esc on a keyboard — your best score is kept on this device.</p>
      </div>
    </div>
  );
}
