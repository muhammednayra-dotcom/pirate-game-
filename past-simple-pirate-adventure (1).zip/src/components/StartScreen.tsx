import { useState } from "react";
import { ISLANDS } from "../game/data";
import type { HighScore } from "../game/highscores";
import { Coin, Key, Star } from "./Illustrations";
import IslandScene from "./IslandScene";
import { Logo, MascotBubble, SoundOffIcon, SoundOnIcon } from "./UI";

interface Props {
  name: string;
  onNameChange: (name: string) => void;
  onStart: () => void;
  muted: boolean;
  onToggleSound: () => void;
  highScores: HighScore[];
}

const STEPS = [
  { icon: "🧭", title: "Answer 5 clues", text: "Every island has 5 pirate puzzles about the past simple.", color: "#2E86DE" },
  { icon: "🪙", title: "Earn gold coins", text: "Each correct answer earns a shiny coin. Wrong? Try again!", color: "#E5A00B" },
  { icon: "🗝️", title: "Collect golden keys", text: "Finish all 5 clues to win a key and sail to the next island.", color: "#159F7A" },
  { icon: "💎", title: "Find the treasure", text: "Gather 10 keys to open the grand treasure chest!", color: "#E1557B" },
];

export default function StartScreen({ name, onNameChange, onStart, muted, onToggleSound, highScores }: Props) {
  const [showHow, setShowHow] = useState(false);
  const best = highScores[0]?.score ?? 0;

  return (
    <div className="relative min-h-[100dvh] overflow-hidden bg-[linear-gradient(180deg,#8fe7ee_0%,#c9f6ef_38%,#ffe9bb_100%)] pb-20">
      {/* soft sky decorations */}
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <div className="absolute -left-16 top-10 h-56 w-56 rounded-full bg-white/50 blur-2xl" />
        <div className="absolute right-[8%] top-6 h-24 w-24 rounded-full bg-[#FFE07A] shadow-[0_0_60px_20px_rgba(255,224,122,0.55)]" />
        <div className="absolute right-[22%] top-16 hidden h-8 w-24 opacity-60 sm:block">
          <svg viewBox="0 0 100 30" className="h-full w-full"><path d="M10 20 Q25 6 40 18 Q55 5 70 18 Q85 10 92 20" fill="none" stroke="#fff" strokeWidth="4" strokeLinecap="round" /></svg>
        </div>
      </div>

      <div className="relative mx-auto w-full max-w-6xl px-3 pt-3 sm:px-6 sm:pt-5">
        <div className="flex items-center justify-between gap-3">
          <div className="rounded-2xl bg-[#073b4c]/95 px-2.5 py-2 shadow-lg sm:rounded-3xl sm:px-4 sm:py-2.5">
            <Logo />
          </div>
          <div className="flex items-center gap-2">
            <button type="button" onClick={() => setShowHow((prev) => !prev)} className="btn btn-ghost hidden !px-4 !py-2 !text-sm sm:inline-flex">
              📖 How to play
            </button>
            <button
              type="button"
              onClick={onToggleSound}
              className="icon-btn !bg-[#073b4c]/90 !border-white/50"
              aria-label={muted ? "Turn music on" : "Turn music off"}
              title={muted ? "Music off" : "Music on"}
            >
              {muted ? <SoundOffIcon /> : <SoundOnIcon />}
            </button>
          </div>
        </div>

        <div className="mt-4 grid items-center gap-4 sm:mt-6 lg:grid-cols-[1.03fr_0.97fr] lg:gap-8">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full border-2 border-[#0c6b73]/20 bg-white/80 px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#0c6b73] sm:text-[11px]">
                ⚓ Past Simple · A1–A2
              </span>
              <span className="inline-flex items-center gap-1 rounded-full bg-[#F26B4E] px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.12em] text-white sm:text-[11px]">
                Ages 6–10
              </span>
            </div>

            <h1 className="mt-2 font-display text-[2.6rem] font-extrabold leading-[0.92] tracking-tight text-[#073b4c] sm:text-6xl lg:text-[4.3rem]">
              Sail into the
              <br />
              <span className="relative inline-block text-[#c47a00]">
                <span className="relative z-10">Past Simple!</span>
                <svg viewBox="0 0 300 20" className="absolute -bottom-2 left-0 z-0 h-4 w-full" preserveAspectRatio="none" aria-hidden="true">
                  <path d="M4 12 Q76 2 150 10 T296 8" fill="none" stroke="#F5B51B" strokeWidth="9" strokeLinecap="round" opacity=".8" />
                </svg>
              </span>
            </h1>
            <p className="mt-3 max-w-md text-sm font-bold leading-relaxed text-[#255a63] sm:text-base">
              Ahoy, little pirate! Set sail across 10 magical islands, solve 50 playful clues and collect golden keys to find the legendary treasure.
            </p>

            <div className="mt-3 flex flex-wrap items-center gap-2 sm:gap-3">
              <span className="flex items-center gap-1.5 rounded-xl bg-white/80 px-2.5 py-1.5 text-xs font-extrabold text-[#07505c] shadow-sm"><span aria-hidden="true">🏝️</span> 10 islands</span>
              <span className="flex items-center gap-1.5 rounded-xl bg-white/80 px-2.5 py-1.5 text-xs font-extrabold text-[#07505c] shadow-sm"><span aria-hidden="true">🧩</span> 50 clues</span>
              <span className="flex items-center gap-1.5 rounded-xl bg-white/80 px-2.5 py-1.5 text-xs font-extrabold text-[#07505c] shadow-sm"><span aria-hidden="true">🗝️</span> 10 keys</span>
              <span className="flex items-center gap-1.5 rounded-xl bg-white/80 px-2.5 py-1.5 text-xs font-extrabold text-[#07505c] shadow-sm"><Star className="h-3.5 w-3.5 text-[#E5A00B]" /> Best: {best}</span>
            </div>

            <div className="mt-4 rounded-2xl border-2 border-white bg-white/85 p-3 shadow-[0_16px_30px_-16px_rgba(4,60,70,0.45)] backdrop-blur sm:p-4">
              <label htmlFor="pirate-name" className="mb-1 block text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#0c6b73]">
                Your pirate name
              </label>
              <div className="flex flex-col gap-2.5 sm:flex-row">
                <input
                  id="pirate-name"
                  value={name}
                  onChange={(event) => onNameChange(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter") onStart();
                  }}
                  maxLength={18}
                  placeholder="Captain Clever"
                  autoComplete="off"
                  className="min-w-0 flex-1 rounded-xl border-2 border-[#d6e8ea] bg-white px-3 py-2.5 font-display text-base font-extrabold text-[#073b4c] placeholder:font-sans placeholder:font-semibold placeholder:text-[#9bb4b9] focus:border-[#159c9c] focus:outline-none"
                />
                <button type="button" onClick={onStart} className="btn btn-primary group whitespace-nowrap !px-5 !py-3 !text-base sm:!px-7 sm:!text-lg">
                  Set Sail! <span className="inline-block text-xl transition-transform group-hover:translate-x-1" aria-hidden="true">⛵</span>
                </button>
              </div>
              <div className="mt-2 flex flex-wrap items-center justify-between gap-1">
                <p className="text-[10px] font-bold text-[#6b8b94] sm:text-[11px]">No sign-up. Progress saves your best score.</p>
                <button type="button" onClick={() => setShowHow((prev) => !prev)} className="text-[10px] font-extrabold uppercase tracking-wide text-[#0c6b73] underline decoration-dotted underline-offset-2 sm:hidden">
                  How to play
                </button>
              </div>
            </div>

            <div className="mt-2 flex flex-wrap items-center gap-1.5 rounded-xl border border-[#0c6b73]/15 bg-white/55 px-2.5 py-2 text-[10px] font-bold text-[#255a63] sm:text-[11px]">
              <span className="rounded-md bg-[#e5fbf3] px-1.5 py-0.5 font-extrabold text-[#127a5c]">Regular + -ed</span>
              <span className="font-display font-extrabold">play → played</span>
              <span className="text-[#0c6b73]/30">|</span>
              <span className="rounded-md bg-[#fff1da] px-1.5 py-0.5 font-extrabold text-[#a85d0b]">Irregular</span>
              <span className="font-display font-extrabold">go → went</span>
            </div>
          </div>

          <div className="relative">
            <div className="relative overflow-hidden rounded-3xl gold-frame">
              <IslandScene island={ISLANDS[9]} questionsDone={0} celebrating overlay={false} className="aspect-[2.15/1] sm:aspect-[2.4/1] lg:aspect-auto lg:h-[290px]" />
              <div className="absolute right-3 top-3 rotate-2 rounded-xl border-2 border-[#f5d78a] bg-[#073b4c]/90 px-3 py-1.5 text-center shadow-lg backdrop-blur-sm">
                <p className="font-display text-xs font-extrabold uppercase tracking-widest text-[#ffe9a8]">Goal</p>
                <p className="font-display text-lg font-extrabold leading-none text-white">THE TREASURE!</p>
              </div>
              <MascotBubble message="Ahoy! I'm Pip. Let's find the treasure!" tone="cheer" small />
              <div className="pointer-events-none absolute left-2 top-2 flex -rotate-3 items-center gap-1 rounded-lg bg-white/95 px-2 py-1 text-[10px] font-extrabold text-[#07505c] shadow-md sm:text-xs">
                <Coin className="h-4 w-4" /> 50 coins to collect
              </div>
            </div>
            <div className="absolute -bottom-3 left-3 flex -rotate-2 items-center gap-1.5 rounded-xl border-2 border-[#f0d9aa] bg-white px-2.5 py-1.5 shadow-lg sm:left-6">
              <Key className="h-5 w-5" />
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#0c6b73] sm:text-xs">10 golden keys</span>
            </div>
          </div>
        </div>

        {showHow && (
          <div className="feedback-rise mt-5 rounded-2xl border-2 border-white/80 bg-[#073b4c]/95 p-3 text-white shadow-xl sm:p-4">
            <div className="flex items-center justify-between gap-2">
              <p className="font-display text-base font-extrabold text-[#ffe9a8] sm:text-lg">How to play, matey</p>
              <button type="button" onClick={() => setShowHow(false)} className="text-[10px] font-extrabold uppercase tracking-widest text-white/70 hover:text-white">Close ✕</button>
            </div>
            <div className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
              {STEPS.map((step) => (
                <div key={step.title} className="rounded-xl border border-white/15 bg-white/10 p-2.5">
                  <span className="text-xl" aria-hidden="true">{step.icon}</span>
                  <p className="font-display text-sm font-extrabold">{step.title}</p>
                  <p className="text-[11px] font-semibold leading-snug text-white/75">{step.text}</p>
                </div>
              ))}
            </div>
            <p className="mt-2 text-[11px] font-semibold text-white/70">Keyboard: numbers choose answers, R/I sort regular or irregular, Enter continues, Esc pauses. Touch works everywhere!</p>
          </div>
        )}

        <div className="mt-6 grid gap-3 lg:grid-cols-[1.25fr_1fr]">
          <div className="rounded-2xl border-2 border-white/80 bg-white/80 p-3 shadow-lg backdrop-blur sm:p-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-base font-extrabold text-[#073b4c] sm:text-lg">Your treasure map</h2>
              <span className="rounded-full bg-[#ddf7f3] px-2 py-1 text-[9px] font-extrabold uppercase tracking-wider text-[#0c6b73]">10 islands</span>
            </div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {ISLANDS.map((island) => (
                <div key={island.id} className="flex items-center gap-1 rounded-lg border border-[#e4dcc6] bg-[#fffdf7] px-2 py-1 text-[10px] font-extrabold text-[#4d6b74] shadow-sm sm:text-[11px]" title={island.tagline}>
                  <span aria-hidden="true">{island.icon}</span> {island.name}
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border-2 border-[#f0d9aa] bg-[#073b4c]/95 p-3 text-white shadow-xl sm:p-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-base font-extrabold text-[#ffe9a8] sm:text-lg">🏆 Pirate hall of fame</h2>
              <span className="text-[9px] font-bold uppercase tracking-wider text-white/50">Local</span>
            </div>
            {highScores.length === 0 ? (
              <p className="mt-2 rounded-xl border border-dashed border-white/25 px-3 py-3 text-center text-[11px] font-bold text-white/60 sm:text-xs">
                No pirate has finished a voyage yet. Your name could shine here first! ✨
              </p>
            ) : (
              <ol className="mt-2 space-y-1">
                {highScores.slice(0, 4).map((entry, index) => (
                  <li key={`${entry.name}-${entry.date}-${index}`} className="flex items-center gap-2 rounded-lg bg-white/10 px-2 py-1.5 text-[11px] sm:text-xs">
                    <span className="w-4 text-center">{["🥇", "🥈", "🥉"][index] ?? `${index + 1}.`}</span>
                    <span className="min-w-0 flex-1 truncate font-display font-extrabold">{entry.name}</span>
                    <span className="flex items-center gap-0.5 text-[#ffe9a8]"><Star className="h-3 w-3" /> {entry.score}</span>
                    <span className="text-white/50">{entry.keys}/10 🗝️</span>
                  </li>
                ))}
              </ol>
            )}
          </div>
        </div>
      </div>

      {/* bottom ocean ribbon */}
      <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-14 overflow-hidden" aria-hidden="true">
        <svg viewBox="0 0 1440 80" preserveAspectRatio="none" className="h-full w-full">
          <path d="M0 38c120-24 240 16 360 0s240-22 360 0 240 20 360 0 240-14 360 2v40H0z" fill="#1a9fb0" opacity=".85" />
          <path d="M0 54c120-20 240 10 360-2s240-18 360 2 240 12 360-4 240-8 360 6v24H0z" fill="#0c7a8e" />
        </svg>
      </div>
    </div>
  );
}
