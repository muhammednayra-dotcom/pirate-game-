import { useMemo, type ReactNode } from "react";
import { ISLANDS } from "../game/data";
import { Coin, CompassIcon, Key, Parrot, Star } from "./Illustrations";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="relative grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-gradient-to-b from-[#ffe393] to-[#f5b51b] shadow-[0_3px_0_#b87505,inset_0_1px_0_#fff6cc] sm:h-12 sm:w-12">
        <CompassIcon className="h-7 w-7 sm:h-8 sm:w-8" />
        <span className="absolute -right-1 -top-1 text-sm">🏴‍☠️</span>
      </div>
      <div className="leading-none">
        <p className="text-[8px] font-extrabold uppercase tracking-[0.24em] text-[#ffdf8a] sm:text-[10px]">The Past Simple</p>
        <p className={`font-display font-extrabold tracking-tight text-white ${compact ? "text-base sm:text-lg" : "text-lg sm:text-2xl"}`}>
          Pirate Adventure
        </p>
        {!compact && <p className="mt-0.5 hidden text-[11px] font-semibold text-white/65 sm:block">Treasure Island Quest</p>}
      </div>
    </div>
  );
}

export function StatPill({
  icon,
  value,
  label,
  tone = "gold",
  compact = false,
}: {
  icon: ReactNode;
  value: number | string;
  label: string;
  tone?: "gold" | "coral" | "mint" | "sky";
  compact?: boolean;
}) {
  const tones = {
    gold: "border-[#ffdf8a]/50 bg-[#3a3116]/80 text-[#ffe9a8]",
    coral: "border-[#ffb3a3]/40 bg-[#40211b]/80 text-[#ffd0c5]",
    mint: "border-[#9eeed3]/40 bg-[#103a37]/80 text-[#c9ffed]",
    sky: "border-[#a9e4ff]/40 bg-[#0d3548]/80 text-[#d6f5ff]",
  } as const;
  return (
    <div
      className={`flex items-center gap-1.5 rounded-xl border px-2 py-1.5 sm:rounded-2xl sm:px-3 sm:py-2 ${tones[tone]}`}
      aria-label={`${label}: ${value}`}
    >
      <span className="grid h-5 w-5 shrink-0 place-items-center sm:h-6 sm:w-6">{icon}</span>
      <span className="flex flex-col leading-none">
        <span className="font-display text-sm font-extrabold tabular-nums sm:text-lg">{value}</span>
        {!compact && <span className="mt-0.5 hidden text-[9px] font-bold uppercase tracking-[0.12em] opacity-70 sm:block">{label}</span>}
      </span>
    </div>
  );
}

export function JourneyMap({ current, keys, compact = false }: { current: number; keys: number; compact?: boolean }) {
  return (
    <div className="w-full" aria-label={`Journey progress: island ${current} of ${ISLANDS.length}, ${keys} keys collected`}>
      <div className="relative flex items-center justify-between gap-0.5">
        <div className="absolute left-2 right-2 top-1/2 -z-0 h-[3px] -translate-y-1/2 rounded-full bg-white/20" />
        <div
          className="absolute left-2 top-1/2 -z-0 h-[3px] -translate-y-1/2 rounded-full bg-gradient-to-r from-[#ffd76b] to-[#f5b51b] transition-all duration-700"
          style={{ width: `calc((100% - 1rem) * ${Math.min(keys, ISLANDS.length) / ISLANDS.length})` }}
        />
        {ISLANDS.map((island) => {
          const done = island.id <= keys;
          const active = island.id === current && !done;
          return (
            <div key={island.id} className="relative z-10 flex min-w-0 flex-1 flex-col items-center">
              <div
                className={`grid place-items-center rounded-full border-2 font-display text-[10px] font-extrabold transition-all sm:text-xs ${
                  compact ? "h-6 w-6" : "h-7 w-7 sm:h-8 sm:w-8"
                } ${
                  done
                    ? "border-[#ffe393] bg-gradient-to-b from-[#ffe393] to-[#f5b51b] text-[#5b3a00] shadow-[0_0_0_3px_rgba(255,227,147,0.2)]"
                    : active
                      ? "animate-pulse border-white bg-white text-[#073b4c] shadow-[0_0_0_4px_rgba(255,255,255,0.22)]"
                      : "border-white/25 bg-[#06404f] text-white/60"
                }`}
                title={`${island.id}. ${island.name}`}
              >
                {done ? "🔑" : active ? <span className="text-[11px]">{island.icon}</span> : island.id}
              </div>
              {!compact && (
                <span
                  className={`mt-1 hidden max-w-full truncate text-[8.5px] font-bold uppercase tracking-wide lg:block ${
                    done ? "text-[#ffe9a8]" : active ? "text-white" : "text-white/40"
                  }`}
                >
                  {island.name}
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function Hud({
  coins,
  keys,
  score,
  currentIsland,
  muted,
  onToggleSound,
  onPause,
  paused,
}: {
  coins: number;
  keys: number;
  score: number;
  currentIsland: number;
  muted: boolean;
  onToggleSound: () => void;
  onPause: () => void;
  paused: boolean;
}) {
  const controls = (
    <>
      <button type="button" className="icon-btn !h-9 !w-9 sm:!h-10 sm:!w-10" onClick={onToggleSound} aria-label={muted ? "Turn sound on" : "Turn sound off"} title={muted ? "Sound off" : "Sound on"}>
        {muted ? <SoundOffIcon /> : <SoundOnIcon />}
      </button>
      <button type="button" className="icon-btn !h-9 !w-9 sm:!h-10 sm:!w-10" onClick={onPause} aria-label={paused ? "Resume game" : "Pause game"} title="Pause (Esc)">
        {paused ? <PlayIcon /> : <PauseIcon />}
      </button>
    </>
  );
  const stats = (
    <>
      <StatPill icon={<Coin />} value={coins} label="Coins" tone="gold" />
      <StatPill icon={<Key />} value={`${keys}/10`} label="Keys" tone="coral" />
      <StatPill icon={<Star className="text-[#ffd76b]" />} value={score} label="Score" tone="mint" />
    </>
  );

  return (
    <header className="deep-panel rounded-2xl px-2.5 py-2 sm:rounded-3xl sm:px-4 sm:py-3">
      <div className="flex items-center gap-2 sm:gap-4">
        <div className="min-w-0 shrink origin-left scale-[0.96] sm:scale-100">
          <Logo compact />
        </div>
        <div className="ml-auto hidden items-center gap-1.5 sm:flex sm:gap-2">
          {stats}
          {controls}
        </div>
        <div className="ml-auto flex items-center gap-1.5 sm:hidden">{controls}</div>
      </div>
      <div className="mt-1.5 flex items-center gap-1.5 sm:hidden">{stats}</div>
      <div className="mt-2 border-t border-white/10 pt-2 sm:mt-3 sm:pt-2.5">
        <div className="mb-1 flex items-center justify-between text-[8px] font-extrabold uppercase tracking-[0.16em] text-white/55 sm:text-[9px]">
          <span>Voyage progress</span>
          <span>
            Island {currentIsland}/{ISLANDS.length} · {keys} golden {keys === 1 ? "key" : "keys"}
          </span>
        </div>
        <JourneyMap current={currentIsland} keys={keys} />
      </div>
    </header>
  );
}

export function MascotBubble({ message, tone = "happy", small = false }: { message: string; tone?: "happy" | "oops" | "cheer"; small?: boolean }) {
  return (
    <div className={`pointer-events-none absolute bottom-2 left-2 z-20 flex items-end gap-1.5 sm:bottom-4 sm:left-4 sm:gap-2 ${small ? "max-w-[70%]" : "max-w-[78%] sm:max-w-[62%]"}`}>
      <Parrot className={`${small ? "h-12 w-12" : "h-16 w-16 sm:h-20 sm:w-20"} shrink-0 drop-shadow-lg ${tone === "oops" ? "parrot-bob" : "float-slow"}`} />
      <div
        className={`feedback-rise relative mb-2 rounded-2xl rounded-bl-md border-2 px-2.5 py-1.5 text-[11px] font-extrabold leading-snug shadow-lg sm:px-3.5 sm:py-2 sm:text-sm ${
          tone === "oops"
            ? "border-[#ffc0ad] bg-[#fff4ef] text-[#9a3b22]"
            : tone === "cheer"
              ? "border-[#ffe08a] bg-[#fffbe8] text-[#7a5200]"
              : "border-white bg-white/95 text-[#07505c]"
        }`}
        role="status"
        aria-live="polite"
      >
        {message}
        <span className="absolute -left-1.5 bottom-2 h-3 w-3 rotate-45 border-b-2 border-l-2 border-inherit bg-inherit" />
      </div>
    </div>
  );
}

export function Burst({ id }: { id: number }) {
  const bits = useMemo(
    () =>
      Array.from({ length: 14 }).map((_, i) => ({
        dx: (Math.random() - 0.5) * 260,
        dy: -60 - Math.random() * 150,
        rot: `${Math.random() * 360 - 180}deg`,
        delay: `${Math.random() * 0.12}s`,
        kind: i % 3,
      })),
    [id],
  );
  if (!id) return null;
  return (
    <div key={id} className="pointer-events-none absolute inset-0 z-30 overflow-visible" aria-hidden="true">
      {bits.map((bit, i) => (
        <span
          key={`${id}-${i}`}
          className="particle"
          style={{ "--dx": `${bit.dx}px`, "--dy": `${bit.dy}px`, "--rot": bit.rot, animationDelay: bit.delay } as React.CSSProperties}
        >
          {bit.kind === 0 ? <Coin className="coin-spin h-7 w-7" /> : bit.kind === 1 ? <Star className="h-5 w-5 text-[#ffd76b]" /> : <span className="block h-2.5 w-2.5 rounded-full bg-[#7ce0c3]" />}
        </span>
      ))}
    </div>
  );
}

const CONFETTI_COLORS = ["#F5B51B", "#F26B4E", "#7CE0C3", "#5EC6EC", "#FF9BC0", "#FFF3C4"];
export function Confetti({ pieces = 42 }: { pieces?: number }) {
  const items = useMemo(
    () =>
      Array.from({ length: pieces }).map((_, i) => ({
        left: `${Math.random() * 100}%`,
        delay: `${Math.random() * 2.2}s`,
        duration: `${2.6 + Math.random() * 2.4}s`,
        color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
        sway: `${(Math.random() - 0.5) * 160}px`,
        w: `${6 + Math.random() * 6}px`,
        h: `${10 + Math.random() * 10}px`,
      })),
    [pieces],
  );
  return (
    <div className="pointer-events-none fixed inset-0 z-[60] overflow-hidden" aria-hidden="true">
      {items.map((item, i) => (
        <span
          key={i}
          className="confetti-piece"
          style={{
            left: item.left,
            animationDelay: item.delay,
            animationDuration: item.duration,
            background: item.color,
            "--sway": item.sway,
            width: item.w,
            height: item.h,
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
}

export function SoundOnIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <path d="M4 10v4h3l4 4V6L7 10H4z" />
      <path d="M15.5 8.5a5 5 0 010 7M18 6a8.5 8.5 0 010 12" />
    </svg>
  );
}

export function SoundOffIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <path d="M4 10v4h3l4 4V6L7 10H4z" />
      <path d="M16 9l5 6M21 9l-5 6" />
    </svg>
  );
}

export function PauseIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <rect x="6" y="4" width="4.5" height="16" rx="1.8" />
      <rect x="13.5" y="4" width="4.5" height="16" rx="1.8" />
    </svg>
  );
}

export function PlayIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M7 4.8c0-1.2 1.3-1.9 2.3-1.3l11 7.2c1 .7 1 2.1 0 2.8l-11 7.2c-1 .6-2.3-.1-2.3-1.3V4.8z" />
    </svg>
  );
}

export function CheckIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <path d="M4 12.5l5 5L20 6.5" />
    </svg>
  );
}

export function ArrowIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <path d="M4 12h15M13 5l7 7-7 7" />
    </svg>
  );
}

export function RestartIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <path d="M3 12a9 9 0 1015.5-6.2M3 4v5h5" />
    </svg>
  );
}

export function CloseIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" className={className} aria-hidden="true">
      <path d="M6 6l12 12M18 6L6 18" />
    </svg>
  );
}
