import type { CSSProperties } from "react";

type ArtProps = { className?: string; style?: CSSProperties };

export function Coin({ className = "", style }: ArtProps) {
  return (
    <svg viewBox="0 0 48 48" width="48" height="48" className={className} style={style} aria-hidden="true">
      <circle cx="24" cy="25" r="20" fill="#C98A15" />
      <circle cx="24" cy="23" r="20" fill="#FFD34E" />
      <circle cx="24" cy="23" r="15" fill="#FFE48A" />
      <path d="M24 12.5l3.1 6.3 7 1-5 4.9 1.2 6.9-6.3-3.3-6.3 3.3 1.2-6.9-5-4.9 7-1z" fill="#EBA80F" />
      <circle cx="17" cy="16" r="2.2" fill="#FFF6C9" opacity=".85" />
    </svg>
  );
}

export function Key({ className = "", style }: ArtProps) {
  return (
    <svg viewBox="0 0 48 48" width="48" height="48" className={className} style={style} aria-hidden="true">
      <circle cx="16" cy="16" r="10" fill="#B4780C" />
      <circle cx="16" cy="14" r="10" fill="#FFD34E" />
      <circle cx="16" cy="14" r="4.6" fill="#FFF3B8" />
      <path d="M22 21l16 16" stroke="#C98A15" strokeWidth="7" strokeLinecap="round" />
      <path d="M22 20l16 16" stroke="#FFD34E" strokeWidth="5" strokeLinecap="round" />
      <path d="M31 28l6-6M36 33l5-5" stroke="#FFD34E" strokeWidth="5" strokeLinecap="round" />
      <path d="M12 7l2 2" stroke="#FFF9DC" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}

export function Star({ className = "", style }: ArtProps) {
  return (
    <svg viewBox="0 0 24 24" width="24" height="24" className={className} style={style} aria-hidden="true">
      <path d="M12 2l3 6.6 7 .9-5.2 4.8 1.4 7-6.2-3.4L5.8 21.3l1.4-7L2 9.5l7-.9z" fill="currentColor" />
    </svg>
  );
}

export function CompassIcon({ className = "" }: ArtProps) {
  return (
    <svg viewBox="0 0 40 40" width="40" height="40" className={className} aria-hidden="true">
      <circle cx="20" cy="20" r="17" fill="#FFF6DC" stroke="#E4B34A" strokeWidth="3" />
      <circle cx="20" cy="20" r="2.4" fill="#20606B" />
      <path d="M20 7l4.4 10.3L20 20l-4.4-2.7z" fill="#F26B4E" />
      <path d="M20 33l-4.4-10.3L20 20l4.4 2.7z" fill="#2D8F9B" />
    </svg>
  );
}

export function PirateShip({ className = "", style, sailing = false }: ArtProps & { sailing?: boolean }) {
  return (
    <svg viewBox="0 0 260 210" width="260" height="210" className={className} style={style} aria-hidden="true">
      <ellipse cx="132" cy="192" rx="100" ry="12" fill="#065A78" opacity=".18" />
      <g className={sailing ? "ship-rock sail-tilt" : "ship-rock"}>
        <path d="M30 128c8 32 34 52 96 52s88-20 96-52z" fill="#B9714A" />
        <path d="M30 128h192c3 9 3 15 1 22H29c-2-7-2-13 1-22z" fill="#8E4F32" />
        <path d="M22 120h210c5 0 8 4 7 9-1 4-4 6-9 6H24c-5 0-8-3-8-7 0-4 2-8 6-8z" fill="#F4C25B" />
        <path d="M40 152h172c-4 12-12 19-24 24H64c-12-5-20-12-24-24z" fill="#A65E3D" opacity=".55" />
        <g fill="#FFF3C4" stroke="#8E4F32" strokeWidth="2.4">
          <circle cx="75" cy="164" r="7" />
          <circle cx="105" cy="171" r="6" />
          <circle cx="175" cy="171" r="6" />
          <circle cx="198" cy="164" r="7" />
        </g>
        <path d="M132 133V23" stroke="#7B4B2A" strokeWidth="6" strokeLinecap="round" />
        <path d="M78 36h56" stroke="#7B4B2A" strokeWidth="5" strokeLinecap="round" />
        <path d="M78 40c-12 16-16 40-14 62h52c6-24-4-48-18-62z" fill="#FFF7E4" stroke="#E8C795" strokeWidth="2" />
        <path d="M64 84h52" stroke="#F26B4E" strokeWidth="6" />
        <path d="M134 46c18 10 32 30 38 56h-48V52z" fill="#FFF7E4" stroke="#E8C795" strokeWidth="2" />
        <path d="M128 82h44" stroke="#2D9E8F" strokeWidth="6" />
        <path d="M132 22l30 10-30 10z" fill="#F26B4E" />
        <circle cx="141" cy="32" r="3" fill="#FFF3C4" />
        <path d="M40 120c8-22 20-34 40-40M204 120c-8-22-20-34-40-40" stroke="#7B4B2A" strokeWidth="2.4" fill="none" opacity=".7" />
        <path d="M108 108c7 5 15 5 22 0 4 8-2 16-11 16s-15-8-11-16z" fill="#F4C25B" opacity=".55" />
      </g>
    </svg>
  );
}

export function PalmTree({ className = "", style, flip = false, coconuts = true }: ArtProps & { flip?: boolean; coconuts?: boolean }) {
  return (
    <svg
      viewBox="0 0 130 170"
      width="130"
      height="170"
      className={className}
      style={{ ...style, transform: `${style?.transform ?? ""} ${flip ? "scaleX(-1)" : ""}`.trim() || undefined }}
      aria-hidden="true"
    >
      <path d="M60 168c-2-42 6-74 16-104 3-9 5-15 4-22" stroke="#B6803E" strokeWidth="13" strokeLinecap="round" fill="none" />
      <path d="M60 168c-2-42 6-74 16-104 3-9 5-15 4-22" stroke="#D9A35B" strokeWidth="7" strokeLinecap="round" fill="none" strokeDasharray="12 7" />
      <g fill="#3FA45C">
        <path d="M80 44c14-18 34-22 46-18-10 9-22 14-42 16z" />
        <path d="M80 44c-16-16-34-18-48-12 10 8 22 12 44 14z" fill="#4DBB69" />
        <path d="M80 44C66 26 44 20 30 24c14 10 26 16 47 20z" fill="#62CB76" />
        <path d="M80 44c-6-22 2-40 16-50 2 15-2 31-10 48z" fill="#359A55" />
        <path d="M80 44c16-14 38-14 52-4-14 7-30 9-50 6z" fill="#4DBB69" />
        <path d="M80 44c8-16 26-26 44-24-12 12-24 18-41 26z" fill="#62CB76" />
        <path d="M80 44c-8 10-20 16-34 18 6-12 16-18 30-20z" fill="#359A55" />
      </g>
      {coconuts && (
        <g fill="#9B6535">
          <circle cx="72" cy="54" r="6" />
          <circle cx="85" cy="57" r="5.4" />
          <circle cx="79" cy="64" r="4.8" fill="#B67B45" />
        </g>
      )}
    </svg>
  );
}

export function Parrot({ className = "", style }: ArtProps) {
  return (
    <svg viewBox="0 0 120 130" width="120" height="130" className={className} style={style} aria-hidden="true">
      <path d="M53 86c-2 16-6 28-14 36 12 2 20-4 24-16 4 12 12 16 22 12-8-8-12-20-14-34z" fill="#F26B4E" />
      <path d="M63 88c0 14 0 26-4 36 10-2 16-10 18-22 2 10 8 16 16 18-4-10-6-20-6-32z" fill="#FFC247" />
      <ellipse cx="59" cy="66" rx="30" ry="34" fill="#49B867" />
      <ellipse cx="59" cy="74" rx="20" ry="22" fill="#A7E08A" />
      <path d="M32 56c-10 8-14 22-10 34 6-10 12-18 20-22z" fill="#2F9350" />
      <path d="M36 50c-14-2-24 8-26 20 10-4 18-8 30-8z" fill="#F26B4E" />
      <circle cx="51" cy="48" r="9" fill="#FFF8E8" />
      <circle cx="70" cy="48" r="9" fill="#FFF8E8" />
      <circle cx="52" cy="49" r="4.5" fill="#22404A" />
      <circle cx="69" cy="49" r="4.5" fill="#22404A" />
      <circle cx="53.5" cy="47" r="1.5" fill="#fff" />
      <circle cx="70.5" cy="47" r="1.5" fill="#fff" />
      <path d="M52 66c5 6 12 6 17 0-3 12-14 12-17 0z" fill="#FFB13B" stroke="#E2831D" strokeWidth="2" />
      <path d="M56 70c4 3 8 3 11 0" stroke="#E2831D" strokeWidth="2" fill="none" strokeLinecap="round" />
      <path d="M35 30c8-14 30-16 40-8-6 2-9 8-10 15-10-7-20-8-30-7z" fill="#F26B4E" />
      <path d="M73 22c8 2 11 8 9 14-6 0-11-3-15-8z" fill="#D94E38" />
      <path d="M39 30c10-10 26-12 36-8" stroke="#FFC247" strokeWidth="3" fill="none" strokeLinecap="round" />
      <path d="M52 96l-4 14M66 96l4 14" stroke="#E2831D" strokeWidth="4" strokeLinecap="round" />
    </svg>
  );
}

export function PirateKid({ className = "", style, waving = true }: ArtProps & { waving?: boolean }) {
  return (
    <svg viewBox="0 0 150 190" width="150" height="190" className={className} style={style} aria-hidden="true">
      {/* legs + sandals */}
      <path d="M56 150v22M94 150v22" stroke="#E9B57B" strokeWidth="14" strokeLinecap="round" />
      <path d="M48 174h18M86 174h18" stroke="#8E5B32" strokeWidth="9" strokeLinecap="round" />
      {/* shorts */}
      <path d="M48 132h54l-4 22h-17l-6-12-6 12H52z" fill="#2D7F8B" />
      <path d="M75 132v14" stroke="#1F5F6A" strokeWidth="3" />
      {/* striped shirt */}
      <path d="M49 90c0-13 11-22 26-22s26 9 26 22v42c0 6-5 10-11 10H60c-6 0-11-4-11-10z" fill="#FFF7E4" />
      <path d="M49 97h52M49 108h52M49 119h52" stroke="#35A8B0" strokeWidth="7" />
      <path d="M49 90c0-13 11-22 26-22s26 9 26 22" fill="none" stroke="#0C6B73" strokeWidth="4" />
      {/* arms */}
      <path d="M51 100c-13 4-20 14-20 24 0 5 6 7 9 3 4-7 8-11 14-13z" fill="#E9B57B" />
      {waving ? (
        <path d="M99 100c13-6 19-18 17-32-1-6-9-7-11-1-3 10-6 16-13 20z" fill="#E9B57B" />
      ) : (
        <path d="M99 100c12 4 18 13 18 23 0 5-6 7-9 3-4-7-8-10-14-12z" fill="#E9B57B" />
      )}
      {waving && (
        <g>
          <circle cx="113" cy="65" r="8" fill="#E9B57B" />
          <path d="M108 60l1 4M113 58v4M118 60l-1 4" stroke="#D89A5C" strokeWidth="2" strokeLinecap="round" />
        </g>
      )}
      {/* head */}
      <circle cx="75" cy="58" r="31" fill="#F4C48F" />
      <path d="M44 56c0-18 14-30 31-30s31 12 31 30c-8-8-20-11-31-11s-23 3-31 11z" fill="#E0A66C" opacity=".35" />
      <path d="M43 50c3-16 16-26 32-26s29 10 32 26c-7-5-18-8-32-8s-25 3-32 8z" fill="#F26B4E" />
      <path d="M107 45c8-2 13 2 13 8 0 4-4 7-10 5z" fill="#D94E38" />
      <path d="M43 50c4-4 10-8 18-10M107 45c-10-4-22-6-32-6" stroke="#FFB3A3" strokeWidth="3" fill="none" strokeLinecap="round" />
      <g fill="#FFF8E8">
        <circle cx="63" cy="60" r="8.5" />
        <circle cx="87" cy="60" r="8.5" />
      </g>
      <circle cx="64" cy="61" r="4.4" fill="#3B2A22" />
      <circle cx="86" cy="61" r="4.4" fill="#3B2A22" />
      <circle cx="65.5" cy="59.4" r="1.4" fill="#fff" />
      <circle cx="87.5" cy="59.4" r="1.4" fill="#fff" />
      <circle cx="55" cy="70" r="5" fill="#F59C8A" opacity=".65" />
      <circle cx="95" cy="70" r="5" fill="#F59C8A" opacity=".65" />
      <path d="M69 74c4 4 8 4 12 0" stroke="#9C5A3C" strokeWidth="2.8" fill="none" strokeLinecap="round" />
      {/* little golden key on the belt */}
      <g transform="translate(93 126) scale(0.5)">
        <circle cx="0" cy="0" r="10" fill="#FFD34E" stroke="#C98A15" strokeWidth="3" />
        <path d="M6 6l18 18" stroke="#FFD34E" strokeWidth="7" strokeLinecap="round" />
      </g>
    </svg>
  );
}

export function Dolphin({ className = "", style }: ArtProps) {
  return (
    <svg viewBox="0 0 150 100" width="150" height="100" className={className} style={style} aria-hidden="true">
      <path d="M16 76c14-34 48-58 86-54 16 2 26 12 30 22-10-2-18 0-24 6 8 6 12 16 10 26-16-16-34-22-56-20-16 2-28 8-40 24z" fill="#5EC6EC" />
      <path d="M20 74c20-14 42-20 66-18-16 10-26 22-32 34-12 2-24-4-34-16z" fill="#A9E4F7" />
      <path d="M78 22c2-14 10-22 22-24-2 12-6 20-2 28z" fill="#5EC6EC" />
      <circle cx="112" cy="44" r="4.4" fill="#22404A" />
      <circle cx="113.4" cy="42.6" r="1.5" fill="#fff" />
      <path d="M118 52c5 4 10 3 13-1" stroke="#22404A" strokeWidth="2.6" fill="none" strokeLinecap="round" />
      <circle cx="18" cy="62" r="4" fill="#CFF4FF" opacity=".9" />
      <circle cx="36" cy="44" r="3" fill="#CFF4FF" opacity=".8" />
    </svg>
  );
}

export function Turtle({ className = "", style }: ArtProps) {
  return (
    <svg viewBox="0 0 140 100" width="140" height="100" className={className} style={style} aria-hidden="true">
      <g fill="#48B7A6">
        <ellipse cx="38" cy="68" rx="16" ry="9" transform="rotate(-22 38 68)" />
        <ellipse cx="100" cy="68" rx="16" ry="9" transform="rotate(22 100 68)" />
        <ellipse cx="45" cy="38" rx="12" ry="8" transform="rotate(24 45 38)" />
        <ellipse cx="95" cy="38" rx="12" ry="8" transform="rotate(-24 95 38)" />
      </g>
      <path d="M112 56c10-6 20-4 24 4 3 8-3 16-14 16-8 0-14-5-14-10z" fill="#69CB7F" />
      <circle cx="126" cy="61" r="2.6" fill="#22404A" />
      <path d="M124 69c3 2 6 2 8 0" stroke="#22404A" strokeWidth="1.8" fill="none" strokeLinecap="round" />
      <path d="M24 64c-2-24 18-42 44-42s46 18 44 42z" fill="#2F8C7B" />
      <path d="M32 62c0-18 16-32 36-32s36 14 36 32z" fill="#63C7A9" />
      <g fill="#2F8C7B">
        <path d="M68 32l10 10-10 10-10-10z" />
        <path d="M68 48l9 9-9 9-9-9z" opacity=".75" />
        <path d="M48 44l8 8-8 8-8-8z" opacity=".75" />
        <path d="M88 44l8 8-8 8-8-8z" opacity=".75" />
      </g>
      <path d="M22 70h92" stroke="#2F8C7B" strokeWidth="5" strokeLinecap="round" />
    </svg>
  );
}

export function Seagull({ className = "", style }: ArtProps) {
  return (
    <svg viewBox="0 0 80 40" width="80" height="40" className={className} style={style} aria-hidden="true">
      <path d="M6 26C16 12 28 10 38 20c10-10 24-8 36 6-12-4-22-2-30 6-8-8-18-8-38-6z" fill="#FFFFFF" stroke="#BFD6DE" strokeWidth="1.6" />
      <path d="M38 20c4 4 8 6 12 6" stroke="#BFD6DE" strokeWidth="1.4" fill="none" />
    </svg>
  );
}

export function Cloud({ className = "", style }: ArtProps) {
  return (
    <svg viewBox="0 0 160 70" width="160" height="70" className={className} style={style} aria-hidden="true">
      <g fill="#FFFFFF">
        <ellipse cx="52" cy="46" rx="36" ry="22" />
        <ellipse cx="86" cy="34" rx="30" ry="26" />
        <ellipse cx="116" cy="48" rx="30" ry="18" />
      </g>
    </svg>
  );
}

export function TreasureChest({ className = "", style, open = false }: ArtProps & { open?: boolean }) {
  return (
    <svg viewBox="0 0 200 180" width="200" height="180" className={className} style={style} aria-hidden="true">
      {open && (
        <g>
          <circle cx="100" cy="48" r="56" fill="#FFE98A" opacity=".45" />
          <g className="chest-sparks">
            <path d="M46 40l4 10 10 4-10 4-4 10-4-10-10-4 10-4z" fill="#FFF6C9" />
            <path d="M152 26l3 8 8 3-8 3-3 8-3-8-8-3 8-3z" fill="#FFF6C9" />
            <path d="M140 78l2.5 7 7 2.5-7 2.5-2.5 7-2.5-7-7-2.5 7-2.5z" fill="#FFF6C9" />
          </g>
        </g>
      )}
      <ellipse cx="100" cy="164" rx="76" ry="12" fill="#2A2416" opacity=".16" />
      <g className={open ? "chest-lid-open" : ""} style={{ transformOrigin: "100px 88px" }}>
        <path d="M34 88V64c0-24 20-38 66-38s66 14 66 38v24z" fill="#B9714A" />
        <path d="M34 88V64c0-24 20-38 66-38s66 14 66 38v24z" fill="none" stroke="#8E4F32" strokeWidth="6" />
        <path d="M34 76h132" stroke="#F4C25B" strokeWidth="9" />
        <path d="M54 64c0-18 18-30 46-30s46 12 46 30" fill="none" stroke="#F4C25B" strokeWidth="8" />
        <path d="M86 52h28v22H86z" fill="#F4C25B" stroke="#B4780C" strokeWidth="3" />
        <circle cx="100" cy="63" r="4" fill="#8E4F32" />
      </g>
      <path d="M30 88h140v64c0 6-5 10-11 10H41c-6 0-11-4-11-10z" fill="#C07C4F" />
      <path d="M30 88h140v64c0 6-5 10-11 10H41c-6 0-11-4-11-10z" fill="none" stroke="#8E4F32" strokeWidth="6" />
      <path d="M56 88v66M144 88v66" stroke="#F4C25B" strokeWidth="11" />
      <rect x="86" y="108" width="28" height="30" rx="6" fill="#F4C25B" stroke="#B4780C" strokeWidth="3" />
      <circle cx="100" cy="120" r="4.5" fill="#8E4F32" />
      <path d="M100 124v7" stroke="#8E4F32" strokeWidth="3" strokeLinecap="round" />
      {open && (
        <g className="chest-coins">
          <circle cx="62" cy="82" r="10" fill="#FFD34E" stroke="#C98A15" strokeWidth="2" />
          <circle cx="118" cy="78" r="9" fill="#FFD34E" stroke="#C98A15" strokeWidth="2" />
          <circle cx="90" cy="72" r="8" fill="#FFE48A" stroke="#C98A15" strokeWidth="2" />
          <circle cx="140" cy="92" r="7" fill="#7CE0C3" stroke="#2F8C7B" strokeWidth="2" />
          <circle cx="52" cy="98" r="6" fill="#FF9BC0" stroke="#D94E7E" strokeWidth="2" />
          <path d="M108 66l4 8 8-2-5 7 6 6-9-1-3 8-2-8-9 1 6-6-5-7 8 2z" fill="#C7B3FF" opacity=".9" />
        </g>
      )}
    </svg>
  );
}

export function Coral({ className = "", style }: ArtProps) {
  return (
    <svg viewBox="0 0 100 90" width="100" height="90" className={className} style={style} aria-hidden="true">
      <g fill="none" strokeLinecap="round">
        <path d="M28 88V56l-12-12M28 64l12-12V30M50 88V44M50 60l14-12V32M50 68l-14-10" stroke="#FF9BC0" strokeWidth="9" />
        <path d="M74 88V62l12-12M74 70l-10-10" stroke="#FFC247" strokeWidth="8" />
      </g>
      <circle cx="16" cy="42" r="6" fill="#FFD3E2" />
      <circle cx="64" cy="30" r="6" fill="#FFD3E2" />
      <circle cx="86" cy="48" r="6" fill="#FFE7A8" />
    </svg>
  );
}

export function Shell({ className = "", style }: ArtProps) {
  return (
    <svg viewBox="0 0 60 50" width="60" height="50" className={className} style={style} aria-hidden="true">
      <path d="M4 46C4 22 16 4 30 4s26 18 26 42z" fill="#FFD3C2" />
      <path d="M30 46V8M30 46L14 12M30 46l16-34" stroke="#F7A98C" strokeWidth="2.4" fill="none" />
      <path d="M4 46h52" stroke="#F7A98C" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export function MangoTree({ className = "", style }: ArtProps) {
  return (
    <svg viewBox="0 0 140 160" width="140" height="160" className={className} style={style} aria-hidden="true">
      <path d="M66 160c2-36 0-58-8-82" stroke="#9B6535" strokeWidth="14" strokeLinecap="round" fill="none" />
      <circle cx="62" cy="58" r="42" fill="#3FA45C" />
      <circle cx="92" cy="66" r="30" fill="#4DBB69" />
      <circle cx="40" cy="78" r="28" fill="#359A55" />
      <circle cx="64" cy="40" r="24" fill="#62CB76" />
      <g>
        <ellipse cx="46" cy="66" rx="9" ry="12" fill="#F6A83C" transform="rotate(-18 46 66)" />
        <ellipse cx="84" cy="58" rx="9" ry="12" fill="#FFC247" transform="rotate(18 84 58)" />
        <ellipse cx="70" cy="86" rx="9" ry="12" fill="#F6A83C" />
      </g>
    </svg>
  );
}

export function Starfish({ className = "", style }: ArtProps) {
  return (
    <svg viewBox="0 0 60 60" width="60" height="60" className={className} style={style} aria-hidden="true">
      <path d="M30 4l7 16 17 2-13 12 4 18-15-9-15 9 4-18L6 22l17-2z" fill="#FF9B71" stroke="#F26B4E" strokeWidth="3" />
      <circle cx="30" cy="30" r="4" fill="#FFD8B8" />
    </svg>
  );
}

export function Eyelet({ className = "" }: ArtProps) {
  return (
    <svg viewBox="0 0 24 24" width="24" height="24" className={className} aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
      <path d="M1.8 12S5.4 5.4 12 5.4 22.2 12 22.2 12 18.6 18.6 12 18.6 1.8 12 1.8 12z" />
      <circle cx="12" cy="12" r="3.2" />
    </svg>
  );
}

export function LockIcon({ className = "" }: ArtProps) {
  return (
    <svg viewBox="0 0 24 24" width="24" height="24" className={className} aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
      <rect x="4" y="10" width="16" height="11" rx="3" />
      <path d="M8 10V7a4 4 0 018 0v3" />
    </svg>
  );
}
