import { useEffect, useMemo, useRef, useState } from "react";
import { audio } from "../game/audio";
import { QUESTION_META, isFillCorrect, type Question } from "../game/questions";
import { CheckIcon } from "./UI";

export interface InteractionProps {
  question: Question;
  qNumber: number;
  total: number;
  locked: boolean;
  solved: boolean;
  onWrong: (message?: string) => void;
  onSolved: () => void;
}

function TypeHeader({ question, qNumber, total }: { question: Question; qNumber: number; total: number }) {
  const meta = QUESTION_META[question.type];
  return (
    <div className="mb-2 flex flex-wrap items-center gap-2">
      <span className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider text-white sm:text-[11px]" style={{ background: meta.color }}>
        <span aria-hidden="true">{meta.icon}</span> {meta.label}
      </span>
      <span className="ml-auto rounded-full bg-[#073b4c]/10 px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider text-[#0c6b73] sm:text-[11px]">
        Clue {qNumber} / {total}
      </span>
    </div>
  );
}

function VerbBanner({ question }: { question: Question }) {
  return (
    <div className="mb-3 flex items-center gap-2 rounded-2xl border-2 border-[#f1dfb4] bg-[#fffaf0] p-2 sm:gap-3 sm:p-2.5">
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white text-xl shadow-sm sm:h-11 sm:w-11 sm:text-2xl" aria-hidden="true">
        {question.verb.emoji}
      </span>
      <div className="min-w-0 text-left">
        <p className="text-[9px] font-extrabold uppercase tracking-[0.18em] text-[#9a7635]">Pirate verb</p>
        <p className="font-display text-lg font-extrabold leading-none text-[#073b4c] sm:text-2xl">{question.verb.present}</p>
      </div>
      <span className="ml-auto rounded-full bg-[#e8f7f5] px-2 py-1 text-[9px] font-extrabold uppercase tracking-wide text-[#0c6b73] sm:px-3 sm:text-[10px]">
        present simple
      </span>
    </div>
  );
}

/* ------------------------------- Choose ------------------------------- */
function ChooseQuestion({ question, locked, solved, onWrong, onSolved }: InteractionProps) {
  const [wrong, setWrong] = useState<string[]>([]);
  const [picked, setPicked] = useState<string | null>(null);

  const choose = (option: string) => {
    if (locked || solved || wrong.includes(option)) return;
    if (option === question.correct) {
      setPicked(option);
      audio.correct();
      onSolved();
    } else {
      setWrong((prev) => [...prev, option]);
      audio.wrong();
      onWrong();
    }
  };

  useEffect(() => {
    if (solved || locked) return;
    const handler = (event: KeyboardEvent) => {
      const index = Number(event.key) - 1;
      if (index >= 0 && index < question.options.length) choose(question.options[index]);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  });

  return (
    <>
      <VerbBanner question={question} />
      <p className="mb-2 font-display text-lg font-extrabold leading-tight text-[#073b4c] sm:text-2xl">{question.title}</p>
      <p className="mb-3 text-[13px] font-semibold text-[#3f6875] sm:text-sm">{question.instruction}</p>
      <div className="grid gap-2 sm:grid-cols-3 sm:gap-2.5">
        {question.options.map((option, index) => {
          const isWrong = wrong.includes(option);
          const isRight = solved && option === question.correct;
          return (
            <button
              key={option}
              type="button"
              onClick={() => choose(option)}
              disabled={locked || solved || isWrong}
              className={`answer ${isWrong ? "is-wrong" : ""} ${isRight ? "is-correct" : ""} ${solved && !isRight ? "is-muted" : ""}`}
              aria-label={`Answer ${String.fromCharCode(65 + index)}: ${option}`}
            >
              <span className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg text-xs font-extrabold ${isRight ? "bg-[#27b575] text-white" : isWrong ? "bg-[#f26b4e] text-white" : "bg-[#eef7f8] text-[#0c6b73]"}`}>
                {isRight ? <CheckIcon className="h-4 w-4" /> : isWrong ? "✕" : String.fromCharCode(65 + index)}
              </span>
              <span className="font-display text-base sm:text-lg">{option}</span>
              {isRight && <span className="ml-auto text-sm">🌟</span>}
            </button>
          );
        })}
      </div>
      <p className="mt-2 hidden text-[11px] font-semibold text-[#7d99a1] sm:block">
        Tip: press <kbd className="rounded bg-[#edf4f5] px-1.5 py-0.5 font-bold text-[#3f6875]">1</kbd>–<kbd className="rounded bg-[#edf4f5] px-1.5 py-0.5 font-bold text-[#3f6875]">3</kbd> to choose
      </p>
      {picked && <span className="sr-only">{picked} is correct</span>}
    </>
  );
}

/* --------------------------- Regular or not --------------------------- */
function RegularQuestion({ question, locked, solved, onWrong, onSolved }: InteractionProps) {
  const [wrong, setWrong] = useState<string[]>([]);
  const options = [
    { value: "Regular", hint: "adds -ed", emoji: "🌱", color: "#159F7A" },
    { value: "Irregular", hint: "changes form", emoji: "⚡", color: "#F28C28" },
  ];

  const choose = (value: string) => {
    if (locked || solved || wrong.includes(value)) return;
    if (value === question.correct) {
      audio.correct();
      onSolved();
    } else {
      setWrong((prev) => [...prev, value]);
      audio.wrong();
      onWrong();
    }
  };

  useEffect(() => {
    if (solved || locked) return;
    const handler = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      if (key === "1" || key === "r") choose("Regular");
      if (key === "2" || key === "i") choose("Irregular");
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  });

  return (
    <>
      <VerbBanner question={question} />
      <p className="mb-1 font-display text-lg font-extrabold leading-tight text-[#073b4c] sm:text-2xl">Which treasure chest?</p>
      <p className="mb-3 text-[13px] font-semibold text-[#3f6875] sm:text-sm">{question.instruction}</p>
      <div className="grid gap-2.5 sm:grid-cols-2">
        {options.map((option) => {
          const isWrong = wrong.includes(option.value);
          const isRight = solved && option.value === question.correct;
          return (
            <button
              key={option.value}
              type="button"
              onClick={() => choose(option.value)}
              disabled={locked || solved || isWrong}
              className={`bucket flex min-h-[92px] flex-col items-start justify-center gap-0.5 p-3 text-left sm:min-h-[110px] sm:p-4 ${
                isWrong ? "is-shake" : ""
              } ${isRight ? "!border-[#27b575] !bg-[#e9fff4]" : ""} ${solved && !isRight ? "opacity-45" : ""}`}
              aria-label={`${option.value}: ${option.hint}`}
            >
              <span className="flex w-full items-center gap-2">
                <span className="text-2xl" aria-hidden="true">{option.emoji}</span>
                <span className="font-display text-lg font-extrabold text-[#073b4c] sm:text-2xl">{option.value}</span>
                {isRight && <CheckIcon className="ml-auto h-6 w-6 text-[#159F7A]" />}
                {isWrong && <span className="ml-auto text-lg">💦</span>}
              </span>
              <span className="text-[11px] font-bold text-[#6b8b94] sm:text-xs">
                {option.hint} {option.value === "Regular" ? "· play → played" : "· go → went"}
              </span>
            </button>
          );
        })}
      </div>
      <p className="mt-2 hidden text-[11px] font-semibold text-[#7d99a1] sm:block">
        Tip: press <kbd className="rounded bg-[#edf4f5] px-1.5 py-0.5 font-bold">R</kbd> for regular or <kbd className="rounded bg-[#edf4f5] px-1.5 py-0.5 font-bold">I</kbd> for irregular
      </p>
    </>
  );
}

/* ------------------------------- Fill ------------------------------- */
function FillQuestion({ question, locked, solved, onWrong, onSolved }: InteractionProps) {
  const [value, setValue] = useState("");
  const [showHint, setShowHint] = useState(false);
  const [failed, setFailed] = useState(false);
  const [shake, setShake] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const submit = () => {
    if (locked || solved) return;
    if (!value.trim()) return;
    if (isFillCorrect(value, question.correct)) {
      audio.correct();
      onSolved();
    } else {
      setFailed(true);
      setShake(true);
      window.setTimeout(() => setShake(false), 450);
      audio.wrong();
      onWrong();
    }
  };

  const [before, after] = question.verb.sentence.split("___");

  return (
    <>
      <p className="mb-1 font-display text-lg font-extrabold leading-tight text-[#073b4c] sm:text-2xl">Complete the pirate sentence!</p>
      <p className="mb-2.5 text-[13px] font-semibold text-[#3f6875] sm:text-sm">{question.instruction}</p>
      <div className="mb-3 rounded-2xl border-2 border-[#dceef0] bg-[#f2fbfb] p-3 sm:p-4">
        <div className="flex gap-2">
          <span className="text-xl sm:text-2xl" aria-hidden="true">{question.verb.emoji}</span>
          <p className="text-[15px] font-bold leading-relaxed text-[#123f4c] sm:text-lg">
            {before}
            <span className={`mx-1 inline-grid min-w-[86px] place-items-center rounded-lg border-b-[3px] px-2 py-0.5 font-display font-extrabold ${solved ? "border-[#27b575] bg-[#dcffec] text-[#147a50]" : "border-[#0c6b73] bg-white text-[#0c6b73]"}`}>
              {solved ? question.correct : showHint ? `${question.correct.slice(0, 1)}${"•".repeat(Math.max(question.correct.length - 1, 1))}` : "?"}
            </span>
            {after}
          </p>
        </div>
      </div>
      <form
        onSubmit={(event) => {
          event.preventDefault();
          submit();
        }}
        className="flex flex-col gap-2 sm:flex-row"
      >
        <label htmlFor={`fill-${question.id}`} className="sr-only">Past simple form of {question.verb.present}</label>
        <input
          id={`fill-${question.id}`}
          ref={inputRef}
          value={value}
          onChange={(event) => setValue(event.target.value)}
          disabled={locked || solved}
          autoComplete="off"
          autoCapitalize="none"
          spellCheck={false}
          placeholder={`${question.verb.present} → ...`}
          className={`min-w-0 flex-1 rounded-xl border-[3px] bg-white px-3 py-2.5 font-display text-lg font-extrabold text-[#073b4c] placeholder:font-sans placeholder:text-sm placeholder:font-semibold placeholder:text-[#9dbbc2] focus:border-[#18a1a1] focus:outline-none sm:py-3 sm:text-xl ${shake ? "shake" : ""} ${
            solved ? "border-[#27b575] bg-[#eafff5]" : failed ? "border-[#f26b4e]" : "border-[#dbe9ee]"
          }`}
        />
        <div className="flex gap-2">
          {!solved && (
            <button type="button" onClick={() => setShowHint((prev) => !prev)} className="btn btn-ghost !rounded-xl !px-3 !py-2.5 !text-sm">
              💡 Hint
            </button>
          )}
          <button type="submit" disabled={locked || solved || !value.trim()} className="btn btn-teal flex-1 !rounded-xl !px-4 !py-2.5 !text-sm sm:flex-none sm:!px-5">
            Check <CheckIcon className="h-4 w-4" />
          </button>
        </div>
      </form>
      {showHint && !solved && (
        <p className="mt-2 rounded-lg bg-[#fff7e6] px-2.5 py-1.5 text-[11px] font-bold text-[#8a641f] sm:text-xs">
          It starts with <strong>“{question.correct.slice(0, 1)}”</strong> and has <strong>{question.correct.length}</strong> letters.
        </p>
      )}
      {failed && !solved && <p className="mt-2 text-[11px] font-bold text-[#c4553a] sm:text-xs">Gentle spelling check, matey — you can try again! 💛</p>}
      <p className="mt-2 hidden text-[11px] font-semibold text-[#7d99a1] sm:block">Tip: press <kbd className="rounded bg-[#edf4f5] px-1.5 py-0.5 font-bold">Enter</kbd> to check your word</p>
    </>
  );
}

/* ------------------------------- Match ------------------------------- */
function MatchQuestion({ question, locked, solved, onWrong, onSolved }: InteractionProps) {
  const pairs = question.pairs;
  const presentOrder = useMemo(() => [...pairs].sort(() => Math.random() - 0.5), [question.id]);
  const pastOrder = useMemo(() => [...pairs].sort(() => Math.random() - 0.5), [question.id]);
  const [selected, setSelected] = useState<string | null>(null);
  const [matched, setMatched] = useState<string[]>([]);
  const [wrongPast, setWrongPast] = useState<string | null>(null);
  const [nudge, setNudge] = useState("");

  const pastFor = (present: string) => pairs.find((pair) => pair.present === present)?.past ?? "";

  const tapPresent = (present: string) => {
    if (locked || solved || matched.includes(present)) return;
    audio.click();
    setSelected(present);
    setNudge("");
  };

  const tapPast = (past: string) => {
    if (locked || solved) return;
    if (!selected) {
      setNudge("Pick a present verb on the left first!");
      audio.click();
      return;
    }
    if (matched.some((item) => pastFor(item) === past)) return;
    if (pastFor(selected) === past) {
      const next = [...matched, selected];
      setMatched(next);
      setSelected(null);
      setNudge("");
      if (next.length === pairs.length) {
        audio.correct();
        onSolved();
      } else {
        audio.match();
      }
    } else {
      setWrongPast(past);
      window.setTimeout(() => setWrongPast(null), 450);
      audio.wrong();
      onWrong();
    }
  };

  return (
    <>
      <p className="mb-1 font-display text-lg font-extrabold leading-tight text-[#073b4c] sm:text-2xl">Match the pirate pairs</p>
      <p className="mb-2.5 text-[13px] font-semibold text-[#3f6875] sm:text-sm">{question.instruction}</p>
      <div className="mb-2 flex items-center justify-between rounded-lg bg-[#eaf7f6] px-2.5 py-1.5 text-[10px] font-extrabold uppercase tracking-wide text-[#0c6b73] sm:text-[11px]">
        <span>Present tense</span>
        <span>{matched.length} / {pairs.length} pairs</span>
        <span>Past tense</span>
      </div>
      <div className="grid grid-cols-2 gap-2 sm:gap-3">
        <div className="space-y-2">
          {presentOrder.map((pair) => {
            const done = matched.includes(pair.present) || solved;
            return (
              <button
                key={pair.present}
                type="button"
                onClick={() => tapPresent(pair.present)}
                disabled={locked || solved || matched.includes(pair.present)}
                aria-pressed={selected === pair.present}
                className={`answer min-h-[48px] justify-between !px-2.5 !py-2 sm:!px-3 sm:!py-2.5 ${selected === pair.present ? "!border-[#18a1a1] !bg-[#e7fbfa] !shadow-[0_4px_0_#88d6d3]" : ""} ${
                  done ? "!border-[#27b575] !bg-[#e9fff4]" : ""
                }`}
              >
                <span className="font-display text-sm sm:text-lg">{pair.present}</span>
                {done ? <CheckIcon className="h-4 w-4 shrink-0 text-[#159F7A]" /> : <span className="text-xs text-[#85a2aa]">→</span>}
              </button>
            );
          })}
        </div>
        <div className="space-y-2">
          {pastOrder.map((pair) => {
            const linkedTo = matched.find((present) => pastFor(present) === pair.past);
            const done = Boolean(linkedTo) || solved;
            return (
              <button
                key={pair.past}
                type="button"
                onClick={() => tapPast(pair.past)}
                disabled={locked || solved || Boolean(linkedTo)}
                className={`answer min-h-[48px] justify-between !px-2.5 !py-2 sm:!px-3 sm:!py-2.5 ${wrongPast === pair.past ? "is-wrong" : ""} ${done ? "is-correct locked-pair" : ""}`}
              >
                <span className="font-display text-sm sm:text-lg">{pair.past}</span>
                {done ? <span className="text-xs">🔗</span> : <span className="text-xs text-[#85a2aa]">○</span>}
              </button>
            );
          })}
        </div>
      </div>
      <div className="mt-2 min-h-[18px] text-[11px] font-bold text-[#c4553a] sm:text-xs" role="status">{nudge}</div>
      <p className="mt-1 hidden text-[11px] font-semibold text-[#7d99a1] sm:block">Tip: tap a green present word, then its past partner. Keyboard: Tab + Enter.</p>
    </>
  );
}

/* ------------------------------- Sort ------------------------------- */
function SortQuestion({ question, locked, solved, onWrong, onSolved }: InteractionProps) {
  const [selected, setSelected] = useState<string | null>(null);
  const [placed, setPlaced] = useState<Record<string, "regular" | "irregular">>({});
  const [over, setOver] = useState<"regular" | "irregular" | null>(null);
  const [shakeBucket, setShakeBucket] = useState<"regular" | "irregular" | null>(null);
  const [nudge, setNudge] = useState("");
  const remaining = question.items.filter((item) => !placed[item.present]);

  const assign = (item: (typeof question.items)[number], bucket: "regular" | "irregular") => {
    if (locked || solved) return;
    if (!item) return;
    const correctBucket = item.irregular ? "irregular" : "regular";
    if (bucket === correctBucket) {
      const next = { ...placed, [item.present]: bucket };
      setPlaced(next);
      setSelected(null);
      setNudge("");
      if (Object.keys(next).length === question.items.length) {
        audio.correct();
        onSolved();
      } else {
        audio.match();
      }
    } else {
      setShakeBucket(bucket);
      window.setTimeout(() => setShakeBucket(null), 450);
      setNudge(`${item.present} is a ${correctBucket} verb. Try the other chest!`);
      audio.wrong();
      onWrong();
    }
  };

  const handleDrop = (bucket: "regular" | "irregular", event: React.DragEvent) => {
    event.preventDefault();
    setOver(null);
    const present = event.dataTransfer.getData("text/plain");
    const item = question.items.find((entry) => entry.present === present);
    if (item) assign(item, bucket);
  };

  const buckets = [
    { id: "regular" as const, title: "Regular", sub: "add -ed", emoji: "🌱", color: "#159F7A", bg: "#f0fff9" },
    { id: "irregular" as const, title: "Irregular", sub: "changes", emoji: "⚡", color: "#F28C28", bg: "#fff9ee" },
  ];

  return (
    <>
      <p className="mb-1 font-display text-lg font-extrabold leading-tight text-[#073b4c] sm:text-2xl">Fill the treasure chests!</p>
      <p className="mb-2 text-[13px] font-semibold text-[#3f6875] sm:text-sm">{question.instruction}</p>
      <div className="mb-2.5 flex min-h-[54px] flex-wrap items-center gap-1.5 rounded-xl border-2 border-dashed border-[#cbe4e8] bg-white/60 p-2">
        {remaining.length === 0 ? (
          <span className="px-1 text-xs font-bold text-[#159F7A]">All verbs sorted — shiver me timbers! ✨</span>
        ) : (
          remaining.map((item) => (
            <button
              key={item.present}
              type="button"
              draggable={!locked && !solved}
              onDragStart={(event) => {
                event.dataTransfer.setData("text/plain", item.present);
                event.dataTransfer.effectAllowed = "move";
                setSelected(item.present);
              }}
              onClick={() => {
                if (locked || solved) return;
                audio.click();
                setSelected(item.present);
              }}
              aria-pressed={selected === item.present}
              className={`drag-tile flex items-center gap-1 rounded-xl border-2 px-2.5 py-1.5 font-display text-sm font-extrabold shadow-[0_3px_0_#e3d5b5] transition-all sm:text-base ${
                selected === item.present ? "-translate-y-0.5 border-[#0c6b73] bg-[#e2fbf8] text-[#07505c]" : "border-[#f0dcaa] bg-[#fffaf0] text-[#073b4c] hover:-translate-y-0.5"
              }`}
            >
              <span aria-hidden="true">{item.emoji}</span> {item.present}
            </button>
          ))
        )}
      </div>
      <div className="grid grid-cols-2 gap-2 sm:gap-3">
        {buckets.map((bucket) => {
          const items = question.items.filter((item) => placed[item.present] === bucket.id);
          return (
            <div
              key={bucket.id}
              onDragOver={(event) => {
                event.preventDefault();
                setOver(bucket.id);
              }}
              onDragLeave={() => setOver(null)}
              onDrop={(event) => handleDrop(bucket.id, event)}
              onClick={() => {
                if (locked || solved) return;
                const item = question.items.find((entry) => entry.present === selected);
                if (!item) {
                  setNudge("Tap a verb first, then tap its chest!");
                  return;
                }
                assign(item, bucket.id);
              }}
              className={`bucket min-h-[104px] cursor-pointer p-2 sm:min-h-[128px] sm:p-2.5 ${over === bucket.id ? "is-over" : ""} ${shakeBucket === bucket.id ? "is-shake" : ""}`}
              style={{ background: over === bucket.id ? undefined : bucket.bg }}
            >
              <button
                type="button"
                onClick={(event) => {
                  event.stopPropagation();
                  if (locked || solved) return;
                  const item = question.items.find((entry) => entry.present === selected);
                  if (!item) {
                    setNudge("Tap a verb first, then tap its chest!");
                    return;
                  }
                  assign(item, bucket.id);
                }}
                className="mb-1.5 flex w-full items-center gap-1.5 text-left"
                aria-label={`Put selected verb in ${bucket.title} chest`}
              >
                <span className="text-lg sm:text-xl" aria-hidden="true">{bucket.emoji}</span>
                <span className="font-display text-sm font-extrabold sm:text-lg" style={{ color: bucket.color }}>{bucket.title}</span>
                <span className="ml-auto rounded-full bg-white/80 px-1.5 py-0.5 text-[8px] font-extrabold uppercase tracking-wide sm:text-[9px]" style={{ color: bucket.color }}>
                  {bucket.sub}
                </span>
              </button>
              <div className="flex flex-wrap gap-1">
                {items.map((item) => (
                  <span
                    key={item.present}
                    onClick={(event) => event.stopPropagation()}
                    className="verb-chip locked-pair !border-[#a9e3c8] !bg-[#f0fff8] text-[10px] sm:text-xs"
                  >
                    <CheckIcon className="h-3 w-3 text-[#159F7A]" /> {item.present} → {item.past}
                  </span>
                ))}
                {items.length === 0 && <span className="px-1 text-[10px] font-semibold text-[#8aa7ae] sm:text-xs">Drop a verb here…</span>}
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-2 min-h-[18px] text-[11px] font-bold text-[#b0611e] sm:text-xs" role="status">{nudge}</div>
      <p className="mt-1 hidden text-[11px] font-semibold text-[#7d99a1] sm:block">Tip: drag a word, or tap a word and then tap a chest. Works with touch too!</p>
    </>
  );
}

/* --------------------------- Card wrapper --------------------------- */
export default function QuestionCard({ question, qNumber, total, locked, solved, onWrong, onSolved }: InteractionProps) {
  const props = { question, qNumber, total, locked, solved, onWrong, onSolved };
  return (
    <div className="relative">
      <TypeHeader question={question} qNumber={qNumber} total={total} />
      {question.type === "choose" && <ChooseQuestion {...props} />}
      {question.type === "regular" && <RegularQuestion {...props} />}
      {question.type === "fill" && <FillQuestion {...props} />}
      {question.type === "match" && <MatchQuestion {...props} />}
      {question.type === "sort" && <SortQuestion {...props} />}
    </div>
  );
}
