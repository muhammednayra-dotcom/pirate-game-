import { useEffect, useRef, useState } from "react";
import { audio } from "../game/audio";
import { ISLANDS, QUESTIONS_PER_ISLAND } from "../game/data";
import { QUESTION_META, randomOops, randomPraise, type Question } from "../game/questions";
import IslandScene from "./IslandScene";
import QuestionCard from "./Questions";
import { ArrowIcon, Burst, CheckIcon, MascotBubble } from "./UI";
import { Coin } from "./Illustrations";

interface Props {
  questions: Question[];
  islandIndex: number;
  questionIndex: number;
  paused: boolean;
  onSolve: (firstTry: boolean) => void;
  onAdvance: () => void;
}

const TYPE_HINTS: Record<Question["type"], string> = {
  choose: "Tap the correct past form, matey!",
  regular: "Pop the verb into the right chest!",
  fill: "Type the past verb in the little box.",
  match: "Link each present verb with its past form.",
  sort: "Sort the verbs into the two chests!",
};

export default function GameScreen({ questions, islandIndex, questionIndex, paused, onSolve, onAdvance }: Props) {
  const island = ISLANDS[islandIndex];
  const question = questions[questionIndex];
  const [solved, setSolved] = useState(false);
  const [hadMistake, setHadMistake] = useState(false);
  const [feedback, setFeedback] = useState<{ tone: "cheer" | "oops"; text: string } | null>(null);
  const [burst, setBurst] = useState(0);
  const [shaking, setShaking] = useState(false);
  const solveRef = useRef(false);

  useEffect(() => {
    setSolved(false);
    setHadMistake(false);
    setFeedback(null);
    solveRef.current = false;
    window.scrollTo(0, 0);
  }, [islandIndex, questionIndex]);

  const handleWrong = () => {
    setHadMistake(true);
    setFeedback({ tone: "oops", text: randomOops() });
    setShaking(true);
    window.setTimeout(() => setShaking(false), 460);
  };

  const handleSolved = () => {
    if (solveRef.current) return;
    solveRef.current = true;
    setSolved(true);
    setBurst((value) => value + 1);
    setFeedback({ tone: "cheer", text: `${randomPraise()} +1 coin!` });
    onSolve(!hadMistake);
  };

  const handleAdvance = () => {
    if (!solved || paused) return;
    audio.click();
    onAdvance();
  };

  useEffect(() => {
    if (!solved || paused) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key !== "Enter") return;
      const target = event.target as HTMLElement | null;
      const tag = target?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || tag === "A") return;
      // An enabled button (like "Next clue") already handles Enter itself.
      if (tag === "BUTTON" && !(target as HTMLButtonElement).disabled) return;
      event.preventDefault();
      handleAdvance();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  });

  const isLastClue = questionIndex === QUESTIONS_PER_ISLAND - 1;
  const meta = QUESTION_META[question.type];
  const mascotMessage = feedback?.text ?? (paused ? "Zzz... the crew is waiting!" : TYPE_HINTS[question.type]);

  return (
    <div className={shaking ? "screen-shake" : ""}>
      <div className="grid items-start gap-3 lg:grid-cols-[0.92fr_1.08fr] lg:gap-4">
        <div className="space-y-3">
          <div className="relative overflow-hidden rounded-2xl gold-frame sm:rounded-3xl">
            <IslandScene
              island={island}
              questionsDone={solved ? questionIndex + 1 : questionIndex}
              celebrating={solved}
              sailing={solved && isLastClue}
              className="aspect-[2.15/1] sm:aspect-[2.4/1] lg:aspect-auto lg:h-[260px]"
            />
            <MascotBubble message={mascotMessage} tone={feedback?.tone ?? "happy"} />
            {!solved && (
              <div className="pointer-events-none absolute bottom-3 right-3 hidden rounded-xl border border-white/50 bg-[#073b4c]/75 px-2 py-1 text-[9px] font-extrabold uppercase tracking-wider text-[#ffe9a8] backdrop-blur-sm sm:block sm:text-[10px]">
                🗝️ 5 clues = 1 key
              </div>
            )}
          </div>
          <div className="hidden rounded-2xl border border-white/25 bg-white/10 p-2.5 text-white backdrop-blur-sm lg:block">
            <p className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#ffe9a8]">
              <span aria-hidden="true">🧭</span> Grammar compass
            </p>
            <div className="mt-1.5 grid grid-cols-2 gap-2">
              <div className="rounded-xl bg-white/10 p-2">
                <p className="font-display text-xs font-extrabold text-[#c9ffed]">Regular</p>
                <p className="font-display text-sm font-extrabold">play → played</p>
                <p className="text-[10px] font-semibold text-white/65">add -ed / -d</p>
              </div>
              <div className="rounded-xl bg-white/10 p-2">
                <p className="font-display text-xs font-extrabold text-[#ffd6a8]">Irregular</p>
                <p className="font-display text-sm font-extrabold">go → went</p>
                <p className="text-[10px] font-semibold text-white/65">the word changes!</p>
              </div>
            </div>
            <p className="mt-1.5 text-center text-[9px] font-extrabold uppercase tracking-[0.14em] text-white/55">yesterday · last week · a long time ago</p>
          </div>
        </div>

        <div className="parchment relative rounded-2xl p-3 sm:rounded-3xl sm:p-4 lg:p-5">
          <Burst id={burst} />
          <div className="mb-2 flex items-center gap-2">
            <div className="flex flex-1 items-center gap-1">
              {Array.from({ length: QUESTIONS_PER_ISLAND }).map((_, index) => (
                <div
                  key={index}
                  className={`h-1.5 flex-1 rounded-full transition-all duration-500 ${
                    index < questionIndex ? "bg-[#f5b51b]" : index === questionIndex ? (solved ? "bg-[#27b575]" : "bg-[#0c6b73]") : "bg-[#e5e2d4]"
                  }`}
                />
              ))}
            </div>
            <span className="font-display text-[10px] font-extrabold uppercase tracking-wider text-[#8a7638] sm:text-xs">
              Island {island.id} of {ISLANDS.length}
            </span>
          </div>

          <QuestionCard
            key={question.id}
            question={question}
            qNumber={questionIndex + 1}
            total={QUESTIONS_PER_ISLAND}
            locked={paused}
            solved={solved}
            onWrong={handleWrong}
            onSolved={handleSolved}
          />

          {paused ? null : solved ? (
            <div className="feedback-rise mt-3 rounded-2xl border-2 border-[#8ee0b6] bg-gradient-to-b from-[#f2fff9] to-[#e4fbef] p-2.5 sm:p-3">
              <div className="flex items-start gap-2">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[#27b575] text-white shadow-[0_3px_0_#199a5e] sm:h-9 sm:w-9">
                  <CheckIcon className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="font-display text-sm font-extrabold leading-tight text-[#106b48] sm:text-base">
                    {hadMistake ? "Great effort — you got it!" : "Ahoy! Brilliant answer!"} <span className="whitespace-nowrap text-[#a56f00]">+1 🪙</span>
                  </p>
                  <p className="mt-0.5 text-[11px] font-bold leading-snug text-[#3f7a65] sm:text-[13px]">{question.explanation}</p>
                </div>
              </div>
              <button type="button" onClick={handleAdvance} className="btn btn-primary mt-2 w-full !py-2.5 !text-sm sm:!py-3 sm:!text-base">
                {isLastClue ? "Collect the island key 🗝️" : "Next clue"} <ArrowIcon className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <div className="mt-2.5 flex min-h-[26px] items-center gap-2">
              {feedback?.tone === "oops" ? (
                <p className="text-[11px] font-extrabold text-[#c4553a] sm:text-xs" role="status">💛 {feedback.text}</p>
              ) : (
                <p className="text-[10px] font-bold text-[#9aa79b] sm:text-[11px]">
                  <span className="mr-1 inline-flex items-center gap-0.5"><Coin className="inline h-3.5 w-3.5" /> Earn a coin for every clue!</span>
                </p>
              )}
              <span className="ml-auto hidden rounded-full px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-white sm:inline" style={{ background: meta.color }}>
                {meta.label}
              </span>
            </div>
          )}
        </div>
      </div>
      <p className="mt-2 text-center text-[10px] font-semibold text-white/70 sm:text-xs">
        <span className="hidden sm:inline">Keyboard: numbers to answer · Enter for next · Esc to pause · </span>
        No losing — every little pirate can try again! 💛
      </p>
    </div>
  );
}
