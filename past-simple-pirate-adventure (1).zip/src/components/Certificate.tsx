import { useRef, useState } from "react";
import { audio } from "../game/audio";

interface Props {
  name: string;
  score: number;
  coins: number;
  keys: number;
}

const displayName = (name: string) => name.trim() || "Little Pirate";

export default function Certificate({ name, score, coins, keys }: Props) {
  const [busy, setBusy] = useState(false);
  const holder = useRef<HTMLDivElement>(null);
  const pirate = displayName(name);
  const today = new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric" }).format(new Date());

  const download = async () => {
    setBusy(true);
    try {
      const canvas = document.createElement("canvas");
      canvas.width = 1600;
      canvas.height = 1130;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const W = canvas.width;
      const H = canvas.height;

      const bg = ctx.createLinearGradient(0, 0, W, H);
      bg.addColorStop(0, "#fffdf3");
      bg.addColorStop(0.55, "#fff6df");
      bg.addColorStop(1, "#ffefc8");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);

      // Decorative ocean corners
      ctx.fillStyle = "#0c6b73";
      ctx.fillRect(0, 0, W, 34);
      ctx.fillRect(0, H - 34, W, 34);
      ctx.fillRect(0, 0, 34, H);
      ctx.fillRect(W - 34, 0, 34, H);
      ctx.strokeStyle = "#e7b94e";
      ctx.lineWidth = 8;
      ctx.strokeRect(62, 62, W - 124, H - 124);
      ctx.strokeStyle = "rgba(12,107,115,0.35)";
      ctx.lineWidth = 3;
      ctx.strokeRect(84, 84, W - 168, H - 168);

      // corner coins
      const cornerCoins: [number, number][] = [[62, 62], [W - 62, 62], [62, H - 62], [W - 62, H - 62]];
      cornerCoins.forEach(([cx, cy]) => {
        ctx.beginPath();
        ctx.arc(cx, cy, 34, 0, Math.PI * 2);
        ctx.fillStyle = "#f5b51b";
        ctx.fill();
        ctx.lineWidth = 8;
        ctx.strokeStyle = "#b87505";
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(cx, cy, 20, 0, Math.PI * 2);
        ctx.fillStyle = "#ffe48a";
        ctx.fill();
      });

      ctx.textAlign = "center";
      ctx.fillStyle = "#0c6b73";
      ctx.font = "bold 34px Georgia, serif";
      ctx.fillText("THE PAST SIMPLE PIRATE ADVENTURE", W / 2, 190);

      ctx.fillStyle = "#b87505";
      ctx.font = "bold 82px Georgia, serif";
      ctx.fillText("Certificate of Achievement", W / 2, 295);

      ctx.fillStyle = "#4d6b74";
      ctx.font = "italic 32px Georgia, serif";
      ctx.fillText("This certificate is proudly awarded to", W / 2, 385);

      ctx.fillStyle = "#073b4c";
      ctx.font = "bold 88px 'Trebuchet MS', sans-serif";
      ctx.fillText(pirate.slice(0, 24), W / 2, 495);

      ctx.strokeStyle = "#e0b352";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(W / 2 - 340, 530);
      ctx.lineTo(W / 2 + 340, 530);
      ctx.stroke();

      ctx.fillStyle = "#255a63";
      ctx.font = "bold 38px 'Trebuchet MS', sans-serif";
      ctx.fillText("for bravely mastering regular and irregular verbs", W / 2, 605);
      ctx.fillText("and finding the legendary Treasure Island!", W / 2, 658);

      // Stats boxes
      const stats = [
        { label: "SCORE", value: `${score}` },
        { label: "GOLD COINS", value: `${coins}` },
        { label: "GOLDEN KEYS", value: `${keys} / 10` },
      ];
      const boxW = 330;
      const gap = 40;
      const startX = W / 2 - (boxW * 3 + gap * 2) / 2;
      stats.forEach((stat, index) => {
        const x = startX + index * (boxW + gap);
        const y = 720;
        ctx.fillStyle = "rgba(12,107,115,0.08)";
        ctx.beginPath();
        ctx.roundRect(x, y, boxW, 150, 22);
        ctx.fill();
        ctx.strokeStyle = "rgba(12,107,115,0.3)";
        ctx.lineWidth = 3;
        ctx.stroke();
        ctx.fillStyle = "#0c6b73";
        ctx.font = "bold 24px 'Trebuchet MS', sans-serif";
        ctx.fillText(stat.label, x + boxW / 2, y + 48);
        ctx.fillStyle = "#073b4c";
        ctx.font = "bold 56px 'Trebuchet MS', sans-serif";
        ctx.fillText(stat.value, x + boxW / 2, y + 115);
      });

      // Seal
      const sealX = W / 2;
      const sealY = 960;
      ctx.beginPath();
      ctx.arc(sealX, sealY, 74, 0, Math.PI * 2);
      ctx.fillStyle = "#f5b51b";
      ctx.fill();
      ctx.lineWidth = 10;
      ctx.strokeStyle = "#b87505";
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(sealX, sealY, 54, 0, Math.PI * 2);
      ctx.fillStyle = "#ffe48a";
      ctx.fill();
      ctx.fillStyle = "#8a5c00";
      ctx.font = "bold 54px 'Trebuchet MS', sans-serif";
      ctx.fillText("★", sealX, sealY + 20);

      ctx.fillStyle = "#4d6b74";
      ctx.font = "bold 26px 'Trebuchet MS', sans-serif";
      ctx.textAlign = "left";
      ctx.fillText(`Awarded ${today}`, 150, 1000);
      ctx.textAlign = "right";
      ctx.fillText("Captain Grammar", W - 150, 1000);
      ctx.strokeStyle = "#0c6b73";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(W - 430, 1018);
      ctx.lineTo(W - 150, 1018);
      ctx.stroke();
      ctx.font = "bold 22px 'Trebuchet MS', sans-serif";
      ctx.fillStyle = "#8a7638";
      ctx.fillText("Keeper of the Golden Keys", W - 150, 1052);

      const url = canvas.toDataURL("image/png");
      const link = document.createElement("a");
      link.download = `past-simple-pirate-certificate-${pirate.replace(/\s+/g, "-").toLowerCase()}.png`;
      link.href = url;
      link.click();
      audio.coin();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <div
        id="certificate"
        ref={holder}
        className="relative overflow-hidden rounded-2xl border-[6px] border-[#0c6b73] bg-[linear-gradient(140deg,#fffdf3,#fff6df_60%,#ffefc8)] p-4 text-center shadow-[0_18px_40px_-18px_rgba(0,20,28,0.6)] sm:p-6"
      >
        <div className="pointer-events-none absolute inset-2 rounded-xl border-2 border-[#e7b94e]" />
        <div className="pointer-events-none absolute left-2 top-2 h-4 w-4 rounded-full bg-[#f5b51b]" />
        <div className="pointer-events-none absolute right-2 top-2 h-4 w-4 rounded-full bg-[#f5b51b]" />
        <div className="pointer-events-none absolute bottom-2 left-2 h-4 w-4 rounded-full bg-[#f5b51b]" />
        <div className="pointer-events-none absolute bottom-2 right-2 h-4 w-4 rounded-full bg-[#f5b51b]" />
        <p className="mt-1 text-[9px] font-extrabold uppercase tracking-[0.28em] text-[#0c6b73] sm:text-[11px]">The Past Simple Pirate Adventure</p>
        <h3 className="mt-1 font-display text-2xl font-extrabold leading-tight text-[#b87505] sm:text-4xl">Certificate of Achievement</h3>
        <p className="mt-1.5 text-[10px] font-semibold italic text-[#4d6b74] sm:text-sm">This certificate is proudly awarded to</p>
        <p className="mt-1 break-words font-display text-3xl font-extrabold leading-tight text-[#073b4c] sm:text-5xl">{pirate}</p>
        <div className="mx-auto mt-1 h-[3px] w-2/3 rounded-full bg-[#e0b352]" />
        <p className="mx-auto mt-2 max-w-sm text-[11px] font-bold leading-snug text-[#255a63] sm:text-sm">
          for bravely mastering regular and irregular verbs and finding the legendary Treasure Island!
        </p>
        <div className="mt-3 grid grid-cols-3 gap-1.5">
          {[
            { label: "Score", value: score },
            { label: "Coins", value: coins },
            { label: "Keys", value: `${keys}/10` },
          ].map((stat) => (
            <div key={stat.label} className="rounded-lg border border-[#0c6b73]/20 bg-[#0c6b73]/5 px-1 py-1.5">
              <p className="text-[8px] font-extrabold uppercase tracking-wider text-[#0c6b73] sm:text-[9px]">{stat.label}</p>
              <p className="font-display text-sm font-extrabold text-[#073b4c] sm:text-lg">{stat.value}</p>
            </div>
          ))}
        </div>
        <div className="mt-3 flex items-end justify-between gap-2 text-left">
          <p className="text-[8px] font-bold text-[#4d6b74] sm:text-[10px]">Awarded {today}</p>
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full border-4 border-[#b87505] bg-[#f5b51b] text-lg text-[#8a5c00] shadow-inner sm:h-14 sm:w-14 sm:text-2xl">★</div>
          <p className="text-right font-display text-[9px] font-extrabold leading-tight text-[#0c6b73] sm:text-[11px]">Captain Grammar<br /><span className="font-sans font-semibold text-[#8a7638]">Keeper of the Keys</span></p>
        </div>
      </div>
      <div className="mt-2 flex flex-col gap-2 sm:flex-row">
        <button type="button" onClick={() => void download()} disabled={busy} className="btn btn-teal flex-1 !py-2.5 !text-sm">
          {busy ? "Making certificate…" : "⬇️ Download certificate"}
        </button>
        <button type="button" onClick={() => window.print()} className="btn btn-ghost flex-1 !py-2.5 !text-sm">
          🖨️ Print
        </button>
      </div>
    </div>
  );
}
