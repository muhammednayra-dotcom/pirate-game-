import { ISLANDS, QUESTIONS_PER_ISLAND, type Island } from "../game/data";
import { Cloud, Coral, Dolphin, MangoTree, PalmTree, Parrot, PirateShip, Seagull, Shell, Starfish, TreasureChest, Turtle } from "./Illustrations";

interface Props {
  island: Island;
  questionsDone: number;
  sailing?: boolean;
  celebrating?: boolean;
  overlay?: boolean;
  className?: string;
}

function Decorations({ island }: { island: Island }) {
  const t = island.theme;
  switch (t.deco) {
    case "parrot":
      return (
        <g>
          <PalmTree className="art" style={{ transform: "translate(560px, 176px) scale(0.95)" }} />
          <Parrot style={{ transform: "translate(724px, 228px) scale(0.78)" }} className="parrot-bob" />
          <Starfish style={{ transform: "translate(500px, 340px) scale(0.8)" }} />
          <Shell style={{ transform: "translate(770px, 344px) scale(0.9)" }} />
        </g>
      );
    case "coral":
      return (
        <g>
          <Coral style={{ transform: "translate(520px, 300px) scale(1.1)" }} />
          <Coral style={{ transform: "translate(760px, 320px) scale(0.8) scaleX(-1)" }} />
          <PalmTree style={{ transform: "translate(660px, 170px) scale(1)" }} />
          <g className="fish-swim">
            <path d="M250 250c14-12 34-8 40 6 6-8 16-10 22-6-2 12-14 22-28 20-16-2-28-10-34-20z" fill="#FFC247" />
            <circle cx="300" cy="255" r="2.4" fill="#22404A" />
          </g>
          <Starfish style={{ transform: "translate(520px, 350px) scale(0.7)" }} />
        </g>
      );
    case "coconut":
      return (
        <g>
          <PalmTree style={{ transform: "translate(520px, 150px) scale(1.05)" }} />
          <PalmTree style={{ transform: "translate(660px, 180px) scale(0.92)" }} flip />
          <PalmTree style={{ transform: "translate(770px, 222px) scale(0.7)" }} />
          <circle cx="610" cy="342" r="9" fill="#9B6535" />
          <circle cx="634" cy="348" r="7" fill="#B67B45" />
          <Shell style={{ transform: "translate(492px, 340px) scale(0.8)" }} />
        </g>
      );
    case "rainbow":
      return (
        <g>
          <g className="rainbow-glow" opacity=".95">
            <path d="M545 190a125 125 0 01250 0" stroke="#FF8FA3" strokeWidth="14" fill="none" strokeLinecap="round" />
            <path d="M562 190a108 108 0 01196 0" stroke="#FFC247" strokeWidth="13" fill="none" strokeLinecap="round" />
            <path d="M579 190a91 91 0 01162 0" stroke="#7CE0C3" strokeWidth="13" fill="none" strokeLinecap="round" />
            <path d="M596 190a74 74 0 01128 0" stroke="#9FB8FF" strokeWidth="13" fill="none" strokeLinecap="round" />
          </g>
          <PalmTree style={{ transform: "translate(560px, 170px) scale(0.95)" }} />
          <PalmTree style={{ transform: "translate(710px, 208px) scale(0.75)" }} flip />
          <Starfish style={{ transform: "translate(660px, 350px) scale(0.75)" }} />
        </g>
      );
    case "dolphin":
      return (
        <g>
          <Dolphin className="dolphin-leap" style={{ transform: "translate(200px, 188px) scale(0.95)" }} />
          <PalmTree style={{ transform: "translate(620px, 176px) scale(1)" }} />
          <PalmTree style={{ transform: "translate(744px, 218px) scale(0.72)" }} flip />
          <Shell style={{ transform: "translate(562px, 344px) scale(0.85)" }} />
          <circle cx="680" cy="360" r="7" fill="#F4CC7B" opacity=".8" />
        </g>
      );
    case "mango":
      return (
        <g>
          <path d="M520 336c48-88 152-136 248-96 42 18 62 52 48 78-16 30-84 40-176 34z" fill="#6BC77E" />
          <MangoTree style={{ transform: "translate(636px, 156px) scale(0.92)" }} />
          <PalmTree style={{ transform: "translate(510px, 218px) scale(0.72)" }} />
          <Shell style={{ transform: "translate(780px, 348px) scale(0.8)" }} />
        </g>
      );
    case "stars":
      return (
        <g>
          <g fill="#FFF4C2">
            <path d="M360 80l4 11 11 4-11 4-4 11-4-11-11-4 11-4z" className="twinkle" />
            <path d="M790 66l5 12 12 5-12 5-5 12-5-12-12-5 12-5z" className="twinkle twinkle-delay" />
            <circle cx="500" cy="62" r="4" />
            <circle cx="680" cy="110" r="3" />
            <circle cx="250" cy="120" r="3.5" />
            <circle cx="850" cy="140" r="4" />
            <path d="M300 180l3 8 8 3-8 3-3 8-3-8-8-3 8-3z" className="twinkle twinkle-delay" />
          </g>
          <PalmTree style={{ transform: "translate(590px, 172px) scale(1)" }} />
          <PalmTree style={{ transform: "translate(730px, 222px) scale(0.7)" }} flip />
          <Starfish style={{ transform: "translate(520px, 350px) scale(0.7)" }} />
        </g>
      );
    case "turtle":
      return (
        <g>
          <PalmTree style={{ transform: "translate(620px, 170px) scale(1)" }} />
          <Turtle className="turtle-walk" style={{ transform: "translate(500px, 308px) scale(0.9)" }} />
          <Shell style={{ transform: "translate(756px, 344px) scale(0.8)" }} />
          <Starfish style={{ transform: "translate(570px, 358px) scale(0.65)" }} />
        </g>
      );
    case "treasure":
      return (
        <g>
          <PalmTree style={{ transform: "translate(520px, 158px) scale(0.95)" }} />
          <PalmTree style={{ transform: "translate(760px, 190px) scale(0.82)" }} flip />
          <g className="chest-glow">
            <TreasureChest style={{ transform: "translate(586px, 244px) scale(0.86)" }} open={false} />
          </g>
          <g stroke="#F4C25B" strokeWidth="5" strokeLinecap="round">
            <path d="M600 236v-22M650 232v-26M700 238v-20" />
          </g>
          <g fill="#FFD34E">
            <circle cx="560" cy="352" r="6" />
            <circle cx="700" cy="360" r="5" />
            <circle cx="792" cy="332" r="4" />
          </g>
          <Starfish style={{ transform: "translate(806px, 350px) scale(0.65)" }} />
        </g>
      );
    default:
      return (
        <g>
          <PalmTree style={{ transform: "translate(540px, 148px) scale(1.08)" }} />
          <PalmTree style={{ transform: "translate(700px, 192px) scale(0.86)" }} flip />
          <Shell style={{ transform: "translate(522px, 344px) scale(0.9)" }} />
          <Starfish style={{ transform: "translate(780px, 348px) scale(0.8)" }} />
          <g className="crab-walk">
            <ellipse cx="630" cy="360" rx="16" ry="10" fill="#F26B4E" />
            <circle cx="622" cy="352" r="2.4" fill="#22404A" />
            <circle cx="638" cy="352" r="2.4" fill="#22404A" />
            <path d="M612 356l-8 4M648 356l8 4" stroke="#F26B4E" strokeWidth="3" strokeLinecap="round" />
          </g>
        </g>
      );
  }
}

export default function IslandScene({ island, questionsDone, sailing = false, celebrating = false, overlay = true, className = "" }: Props) {
  const t = island.theme;
  return (
    <div className={`relative overflow-hidden ${className}`}>
      <svg viewBox="0 0 900 420" preserveAspectRatio="xMidYMid slice" className="h-full w-full" role="img" aria-label={`${island.name}: ${island.tagline}`}>
        <defs>
          <linearGradient id={`sky-${island.id}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={t.skyTop} />
            <stop offset="100%" stopColor={t.skyBottom} />
          </linearGradient>
          <linearGradient id={`sea-${island.id}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={t.seaTop} />
            <stop offset="100%" stopColor={t.seaBottom} />
          </linearGradient>
          <linearGradient id={`sand-${island.id}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={t.sand} />
            <stop offset="100%" stopColor={t.sandShade} />
          </linearGradient>
        </defs>

        <rect width="900" height="420" fill={`url(#sky-${island.id})`} />
        <circle cx="748" cy="88" r="52" fill="#FFF4C2" opacity=".95" />
        <circle cx="748" cy="88" r="68" fill="#FFF4C2" opacity=".28" />
        <g className="clouds-slow" opacity=".9">
          <Cloud style={{ transform: "translate(70px, 50px) scale(0.9)" }} />
          <Cloud style={{ transform: "translate(400px, 30px) scale(0.62)" }} />
        </g>
        <g className="clouds-fast" opacity=".75">
          <Cloud style={{ transform: "translate(600px, 128px) scale(0.5)" }} />
        </g>
        <Seagull className="gull-fly" style={{ transform: "translate(710px, 150px) scale(0.8)" }} />
        <Seagull className="gull-fly gull-delay" style={{ transform: "translate(560px, 118px) scale(0.55)" }} />

        {/* Distant islands */}
        <path d="M0 276c40-34 78-34 118 0z" fill="#2E9C8E" opacity=".35" />
        <path d="M800 272c34-26 72-26 108-2v8H800z" fill="#2E9C8E" opacity=".3" />

        <rect y="264" width="900" height="156" fill={`url(#sea-${island.id})`} />
        <g className="wave-strip wave-back" opacity=".55">
          <path d="M0 292q45-14 90 0t90 0 90 0 90 0 90 0 90 0 90 0 90 0 90 0 90 0V420H0z" fill="#FFFFFF" opacity=".22" />
          <path d="M900 292q45-14 90 0t90 0 90 0 90 0 90 0 90 0 90 0 90 0 90 0 90 0V420H900z" fill="#FFFFFF" opacity=".22" />
        </g>
        <g className="wave-strip wave-mid" opacity=".8">
          <path d="M0 316q50-16 100 0t100 0 100 0 100 0 100 0 100 0 100 0 100 0 100 0V420H0z" fill={t.seaTop} opacity=".7" />
          <path d="M900 316q50-16 100 0t100 0 100 0 100 0 100 0 100 0 100 0 100 0 100 0V420H900z" fill={t.seaTop} opacity=".7" />
        </g>

        {/* Main island */}
        <g>
          <path d="M410 336c30-52 100-80 208-78 108 2 202 32 232 82 20 34-18 58-118 62-140 6-286 0-320-22-14-9-16-26-2-44z" fill={`url(#sand-${island.id})`} />
          <path d="M444 330c46-34 152-50 248-32 56 10 104 32 124 52-58 22-164 30-260 22-64-6-108-20-112-42z" fill={t.sand} opacity=".85" />
          <path d="M466 330c52-24 154-32 240-14 46 10 78 24 94 36-72 14-178 16-260 4-42-6-66-16-74-26z" fill={t.grass} opacity=".55" />
          <Decorations island={island} />
          <g fill="#F4CC7B" opacity=".65">
            <ellipse cx="474" cy="350" rx="26" ry="7" />
            <ellipse cx="812" cy="338" rx="22" ry="6" />
          </g>
        </g>

        {/* The little pirate ship */}
        <g className={sailing ? "scene-ship sailing" : "scene-ship"}>
          <PirateShip sailing={sailing} style={{ transform: "translate(146px, 226px) scale(0.9)" }} />
        </g>

        <g className="wave-strip wave-front">
          <path d="M0 360q50-14 100 0t100 0 100 0 100 0 100 0 100 0 100 0 100 0 100 0V420H0z" fill="#FFFFFF" opacity=".3" />
          <path d="M900 360q50-14 100 0t100 0 100 0 100 0 100 0 100 0 100 0 100 0 100 0V420H900z" fill="#FFFFFF" opacity=".3" />
        </g>

        {/* Foamy shoreline */}
        <path d="M394 364c86-26 238-32 334-6 30 8 44 18 40 26-88 20-282 20-380 4-10-2-6-16 6-24z" fill="#FFFFFF" opacity=".35" />

        {celebrating && (
          <g className="scene-sparkles">
            {[
              [180, 200], [320, 120], [550, 110], [700, 220], [820, 160], [420, 250], [260, 300],
            ].map(([x, y], i) => (
              <path key={i} d={`M${x} ${y}l4 10 10 4-10 4-4 10-4-10-10-4 10-4z`} fill="#FFF6C9" className={i % 2 ? "twinkle twinkle-delay" : "twinkle"} />
            ))}
          </g>
        )}
      </svg>

      {overlay && (
        <>
          <div className="absolute left-3 top-3 flex max-w-[64%] items-center gap-2 rounded-2xl border-2 border-white/70 bg-[#073b4c]/80 px-3 py-2 text-white shadow-lg backdrop-blur-sm sm:left-5 sm:top-5 sm:max-w-[74%] sm:gap-3 sm:px-4">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white/15 text-xl sm:h-11 sm:w-11 sm:text-2xl">{island.icon}</span>
            <div className="min-w-0">
              <p className="text-[9px] font-extrabold uppercase tracking-[0.18em] text-[#FFDA6B] sm:text-[10px]">
                Island {island.id} of {ISLANDS.length}
              </p>
              <p className="truncate font-display text-base font-bold leading-tight sm:text-xl">{island.name}</p>
              <p className="hidden truncate text-[11px] text-white/75 sm:block">{island.tagline}</p>
            </div>
          </div>

          <div className="absolute right-3 top-3 rounded-2xl border-2 border-white/60 bg-white/85 px-2.5 py-1.5 text-[#083b4a] shadow-md backdrop-blur-sm sm:right-5 sm:top-5 sm:px-3 sm:py-2">
            <p className="text-center text-[8px] font-extrabold uppercase tracking-widest text-[#0c6b73] sm:text-[9px]">Island clues</p>
            <div className="mt-1 flex gap-1" aria-label={`${questionsDone} of ${QUESTIONS_PER_ISLAND} questions answered`}>
              {Array.from({ length: QUESTIONS_PER_ISLAND }).map((_, i) => (
                <span
                  key={i}
                  className={`h-2.5 w-2.5 rounded-full transition-all sm:h-3 sm:w-3 ${i < questionsDone ? "bg-[#F5B51B] shadow-[0_0_0_2px_#ffe9a8]" : "bg-[#083b4a]/15"}`}
                />
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
