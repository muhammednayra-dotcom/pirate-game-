import { useCallback, useEffect, useRef, useState } from "react";
import { audio } from "./game/audio";
import { ISLANDS, QUESTIONS_PER_ISLAND } from "./game/data";
import { getHighScores, getPirateName, saveHighScore, savePirateName, type HighScore } from "./game/highscores";
import { generateVoyage, type IslandQuestions } from "./game/questions";
import GameScreen from "./components/GameScreen";
import { IslandClearOverlay, PauseOverlay, VoyageEndScreen } from "./components/Overlays";
import StartScreen from "./components/StartScreen";
import VictoryScreen from "./components/VictoryScreen";
import { Hud } from "./components/UI";

type Phase = "start" | "playing" | "paused" | "islandClear" | "voyageEnd" | "victory";

export default function App() {
  const [phase, setPhase] = useState<Phase>("start");
  const [voyage, setVoyage] = useState<IslandQuestions[]>(() => generateVoyage());
  const [islandIndex, setIslandIndex] = useState(0);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [coins, setCoins] = useState(0);
  const [keys, setKeys] = useState(0);
  const [score, setScore] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [firstTryCount, setFirstTryCount] = useState(0);
  const [streak, setStreak] = useState(0);
  const [runId, setRunId] = useState(0);
  const [name, setName] = useState(() => getPirateName());
  const [muted, setMuted] = useState(() => audio.muted);
  const [highScores, setHighScores] = useState<HighScore[]>(() => getHighScores());
  const recorded = useRef(false);
  const advanceLock = useRef(false);
  const continueLock = useRef(false);

  const island = ISLANDS[islandIndex];
  const currentQuestions = voyage[islandIndex]?.questions ?? voyage[0].questions;

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" && phase === "playing") {
        event.preventDefault();
        setPhase("paused");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase]);

  const recordRun = useCallback(
    (finalKeys: number, finalCoins: number, finalScore: number) => {
      if (recorded.current) return;
      recorded.current = true;
      const entry: HighScore = {
        name: name.trim() || "Little Pirate",
        score: finalScore,
        coins: finalCoins,
        keys: finalKeys,
        islands: finalKeys,
        date: new Date().toISOString(),
      };
      setHighScores(saveHighScore(entry));
    },
    [name],
  );

  const beginVoyage = useCallback(() => {
    audio.start();
    if (!audio.muted) audio.sail();
    setVoyage(generateVoyage());
    setIslandIndex(0);
    setQuestionIndex(0);
    setCoins(0);
    setKeys(0);
    setScore(0);
    setCorrect(0);
    setFirstTryCount(0);
    setStreak(0);
    setRunId((value) => value + 1);
    recorded.current = false;
    advanceLock.current = false;
    continueLock.current = false;
    setPhase("playing");
    window.scrollTo(0, 0);
  }, []);

  const handleName = (value: string) => {
    setName(value);
    savePirateName(value);
  };

  const toggleSound = () => {
    const next = !muted;
    setMuted(next);
    audio.setMuted(next);
    if (!next) audio.click();
  };

  const handleSolve = useCallback(
    (firstTry: boolean) => {
      setCoins((value) => value + 1);
      setCorrect((value) => value + 1);
      if (firstTry) {
        setFirstTryCount((value) => value + 1);
        setScore((value) => value + 20 + streak * 5);
        setStreak((value) => value + 1);
      } else {
        setScore((value) => value + 10);
        setStreak(0);
      }
    },
    [streak],
  );

  const handleAdvance = useCallback(() => {
    if (phase !== "playing" || advanceLock.current) return;
    advanceLock.current = true;
    window.setTimeout(() => {
      advanceLock.current = false;
    }, 450);
    if (questionIndex < QUESTIONS_PER_ISLAND - 1) {
      setQuestionIndex((value) => value + 1);
    } else {
      setKeys((value) => value + 1);
      setScore((value) => value + 50);
      audio.key();
      setPhase("islandClear");
    }
  }, [phase, questionIndex]);

  const handleContinueIsland = useCallback(() => {
    if (continueLock.current) return;
    continueLock.current = true;
    window.setTimeout(() => {
      continueLock.current = false;
    }, 900);
    if (islandIndex < ISLANDS.length - 1) {
      setIslandIndex((value) => value + 1);
      setQuestionIndex(0);
      setPhase("playing");
      if (!audio.muted) audio.sail();
      window.scrollTo(0, 0);
    } else {
      setPhase("victory");
      audio.chest();
      window.setTimeout(() => audio.fanfare(), 500);
      window.scrollTo(0, 0);
    }
  }, [islandIndex]);

  useEffect(() => {
    if (phase === "victory") recordRun(ISLANDS.length, coins, score);
  }, [phase, coins, score, correct, recordRun]);

  const endVoyage = () => {
    recordRun(keys, coins, score);
    setPhase("voyageEnd");
    audio.click();
    window.scrollTo(0, 0);
  };

  const goHome = () => {
    setPhase("start");
    setHighScores(getHighScores());
    window.scrollTo(0, 0);
  };

  if (phase === "start") {
    return (
      <StartScreen
        name={name}
        onNameChange={handleName}
        onStart={beginVoyage}
        muted={muted}
        onToggleSound={toggleSound}
        highScores={highScores}
      />
    );
  }

  if (phase === "voyageEnd") {
    return (
      <VoyageEndScreen
        name={name}
        score={score}
        coins={coins}
        keys={keys}
        correct={correct}
        firstTry={firstTryCount}
        reachedIsland={island}
        highScores={highScores}
        onRestart={beginVoyage}
        onHome={goHome}
      />
    );
  }

  if (phase === "victory") {
    return (
      <VictoryScreen
        name={name}
        score={score}
        coins={coins}
        keys={keys}
        correct={correct}
        firstTry={firstTryCount}
        highScores={highScores}
        onRestart={beginVoyage}
        onHome={goHome}
      />
    );
  }

  return (
    <div className="app-sea min-h-[100dvh] pb-4">
      <div className="mx-auto w-full max-w-6xl px-2 pt-2 sm:px-4 sm:pt-4">
        <Hud
          coins={coins}
          keys={keys}
          score={score}
          currentIsland={islandIndex + 1}
          muted={muted}
          onToggleSound={toggleSound}
          onPause={() => setPhase((current) => (current === "paused" ? "playing" : "paused"))}
          paused={phase === "paused"}
        />

        <main className="mt-2 sm:mt-3">
          <GameScreen
            key={`run-${runId}-${islandIndex}-${questionIndex}`}
            questions={currentQuestions}
            islandIndex={islandIndex}
            questionIndex={questionIndex}
            paused={phase !== "playing"}
            onSolve={handleSolve}
            onAdvance={handleAdvance}
          />
        </main>

        <div className="mx-auto mt-3 flex max-w-2xl flex-wrap items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/10 px-3 py-2 text-[10px] font-bold text-white/75 backdrop-blur-sm sm:text-xs">
          <span className="flex items-center gap-1">🪙 1 coin per clue</span>
          <span className="text-white/30">•</span>
          <span className="flex items-center gap-1">🗝️ 5 clues = 1 key</span>
          <span className="text-white/30">•</span>
          <span className="flex items-center gap-1">💎 10 keys = treasure</span>
        </div>
      </div>

      {phase === "paused" && (
        <PauseOverlay
          islandName={island.name}
          coins={coins}
          keys={keys}
          score={score}
          muted={muted}
          onResume={() => setPhase("playing")}
          onRestart={beginVoyage}
          onEnd={endVoyage}
          onToggleSound={toggleSound}
        />
      )}

      {phase === "islandClear" && (
        <IslandClearOverlay
          island={island}
          keys={keys}
          isLast={islandIndex === ISLANDS.length - 1}
          onContinue={handleContinueIsland}
        />
      )}
    </div>
  );
}
