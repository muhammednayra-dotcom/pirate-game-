export interface HighScore {
  name: string;
  score: number;
  coins: number;
  keys: number;
  islands: number;
  date: string;
}

const KEY = "psp-highscores-v1";
const NAME_KEY = "psp-pirate-name";

export function getHighScores(): HighScore[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as HighScore[];
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((entry) => typeof entry?.score === "number")
      .sort((a, b) => b.score - a.score)
      .slice(0, 6);
  } catch {
    return [];
  }
}

export function saveHighScore(entry: HighScore): HighScore[] {
  const list = [...getHighScores(), entry].sort((a, b) => b.score - a.score).slice(0, 6);
  try {
    localStorage.setItem(KEY, JSON.stringify(list));
  } catch {
    /* ignore */
  }
  return list;
}

export function getPirateName(): string {
  try {
    return localStorage.getItem(NAME_KEY) ?? "";
  } catch {
    return "";
  }
}

export function savePirateName(name: string) {
  try {
    localStorage.setItem(NAME_KEY, name);
  } catch {
    /* ignore */
  }
}
