export interface Verb {
  present: string;
  past: string;
  irregular: boolean;
  sentence: string;
  tip: string;
  emoji: string;
}

export const REGULAR_VERBS: Verb[] = [
  { present: "play", past: "played", irregular: false, sentence: "Yesterday, the pirates ___ a fun game on the beach.", tip: "Just add -ed: play → played.", emoji: "⚽" },
  { present: "visit", past: "visited", irregular: false, sentence: "Last summer, we ___ a beautiful island.", tip: "Add -ed: visit → visited.", emoji: "🏝️" },
  { present: "watch", past: "watched", irregular: false, sentence: "Last night, we ___ the twinkly stars together.", tip: "Add -ed: watch → watched.", emoji: "🔭" },
  { present: "clean", past: "cleaned", irregular: false, sentence: "This morning, the crew ___ the little ship.", tip: "Add -ed: clean → cleaned.", emoji: "🧹" },
  { present: "dance", past: "danced", irregular: false, sentence: "At the beach party, the parrots ___ all evening.", tip: "Add -d: dance → danced.", emoji: "💃" },
  { present: "study", past: "studied", irregular: false, sentence: "Last year, the pirates ___ the treasure map.", tip: "Change y to i: study → studied.", emoji: "🗺️" },
  { present: "stop", past: "stopped", irregular: false, sentence: "The ship ___ near the sunny beach yesterday.", tip: "Double the p: stop → stopped.", emoji: "⚓" },
  { present: "carry", past: "carried", irregular: false, sentence: "The strong pirate ___ the heavy box yesterday.", tip: "Change y to i: carry → carried.", emoji: "📦" },
  { present: "jump", past: "jumped", irregular: false, sentence: "Yesterday, the happy dolphin ___ out of the water.", tip: "Add -ed: jump → jumped.", emoji: "🐬" },
  { present: "travel", past: "travelled", irregular: false, sentence: "Last year, we ___ across the big blue ocean.", tip: "Double the l: travel → travelled. (Traveled is also OK!)", emoji: "🧭" },
];

export const IRREGULAR_VERBS: Verb[] = [
  { present: "go", past: "went", irregular: true, sentence: "Last week, we ___ to a sunny island.", tip: "Irregular verbs change: go → went.", emoji: "🥾" },
  { present: "eat", past: "ate", irregular: true, sentence: "Yesterday, the crew ___ juicy mangoes for breakfast.", tip: "Irregular: eat → ate.", emoji: "🥭" },
  { present: "see", past: "saw", irregular: true, sentence: "Last night, I ___ a bright star in the sky.", tip: "Irregular: see → saw.", emoji: "⭐" },
  { present: "buy", past: "bought", irregular: true, sentence: "The captain ___ a funny new hat yesterday.", tip: "Irregular: buy → bought.", emoji: "🎩" },
  { present: "take", past: "took", irregular: true, sentence: "Yesterday, the cheeky parrot ___ my biscuit!", tip: "Irregular: take → took.", emoji: "🍪" },
  { present: "have", past: "had", irregular: true, sentence: "Last summer, we ___ a lot of fun on the island.", tip: "Irregular: have → had.", emoji: "🎉" },
  { present: "make", past: "made", irregular: true, sentence: "The pirates ___ a giant sandcastle yesterday.", tip: "Irregular: make → made.", emoji: "🏰" },
  { present: "drink", past: "drank", irregular: true, sentence: "Yesterday, the sailor ___ cool coconut juice.", tip: "Irregular: drink → drank.", emoji: "🥥" },
  { present: "write", past: "wrote", irregular: true, sentence: "Last week, I ___ a letter to my best friend.", tip: "Irregular: write → wrote.", emoji: "✉️" },
  { present: "find", past: "found", irregular: true, sentence: "Yesterday, the little pirate ___ a shiny coin.", tip: "Irregular: find → found.", emoji: "🪙" },
  { present: "come", past: "came", irregular: true, sentence: "My friend ___ to my island yesterday.", tip: "Irregular: come → came.", emoji: "🦜" },
  { present: "run", past: "ran", irregular: true, sentence: "The little monkey ___ across the warm sand.", tip: "Irregular: run → ran.", emoji: "🏃" },
  { present: "sleep", past: "slept", irregular: true, sentence: "The sleepy turtle ___ under the palm tree.", tip: "Irregular: sleep → slept.", emoji: "😴" },
  { present: "give", past: "gave", irregular: true, sentence: "The friendly parrot ___ me a golden key.", tip: "Irregular: give → gave.", emoji: "🗝️" },
  { present: "swim", past: "swam", irregular: true, sentence: "Yesterday, we ___ with the friendly fish.", tip: "Irregular: swim → swam.", emoji: "🐠" },
];

export const ALL_VERBS = [...REGULAR_VERBS, ...IRREGULAR_VERBS];

export type DecoKind =
  | "palms"
  | "parrot"
  | "coral"
  | "coconut"
  | "rainbow"
  | "dolphin"
  | "mango"
  | "stars"
  | "turtle"
  | "treasure";

export interface IslandTheme {
  skyTop: string;
  skyBottom: string;
  seaTop: string;
  seaBottom: string;
  sand: string;
  sandShade: string;
  grass: string;
  accent: string;
  accentSoft: string;
  deco: DecoKind;
}

export interface Island {
  id: number;
  name: string;
  tagline: string;
  icon: string;
  theme: IslandTheme;
}

const base = { sand: "#FFE7A8", sandShade: "#F4CC7B", grass: "#5FBF6B" };

export const ISLANDS: Island[] = [
  {
    id: 1,
    name: "Palm Cove",
    tagline: "Where the coconut palms wave hello!",
    icon: "🌴",
    theme: { ...base, skyTop: "#BDEBFF", skyBottom: "#FFF0C2", seaTop: "#45D6CE", seaBottom: "#0F9DC0", accent: "#FF6B6B", accentSoft: "#FFD3D3", deco: "palms", grass: "#63C96E" },
  },
  {
    id: 2,
    name: "Parrot Point",
    tagline: "Listen — the parrots are singing!",
    icon: "🦜",
    theme: { ...base, skyTop: "#A9F1E0", skyBottom: "#FFEFB5", seaTop: "#3ED8B6", seaBottom: "#0E9AA8", accent: "#FF5A5F", accentSoft: "#FFE0B2", deco: "parrot", grass: "#2FA968" },
  },
  {
    id: 3,
    name: "Coral Bay",
    tagline: "A rainbow of fish live here.",
    icon: "🐠",
    theme: { ...base, sand: "#FFE2D6", sandShade: "#F7BFAE", skyTop: "#C6F3FF", skyBottom: "#FFE1EE", seaTop: "#5FE3DC", seaBottom: "#1A8FD1", accent: "#FF7BAC", accentSoft: "#FFE1EC", deco: "coral", grass: "#54C7A2" },
  },
  {
    id: 4,
    name: "Coconut Grove",
    tagline: "Mind your head — coconuts about!",
    icon: "🥥",
    theme: { ...base, skyTop: "#C9EEFF", skyBottom: "#FFE6B8", seaTop: "#41CFC2", seaBottom: "#1386AE", accent: "#F6A83C", accentSoft: "#FFE6C1", deco: "coconut", grass: "#7FCB54" },
  },
  {
    id: 5,
    name: "Rainbow Lagoon",
    tagline: "A lagoon painted with rainbow light.",
    icon: "🌈",
    theme: { ...base, sand: "#FFF0CF", skyTop: "#D6D4FF", skyBottom: "#FFF1C9", seaTop: "#5FE7D8", seaBottom: "#4B83E8", accent: "#A974FF", accentSoft: "#EBDDFF", deco: "rainbow", grass: "#64D3A2" },
  },
  {
    id: 6,
    name: "Dolphin Dunes",
    tagline: "The friendliest dolphins in the sea!",
    icon: "🐬",
    theme: { ...base, sand: "#FFEBC6", sandShade: "#F5D49A", skyTop: "#B9ECFF", skyBottom: "#FFEBC0", seaTop: "#4BDBE6", seaBottom: "#147FB4", accent: "#3CA6F5", accentSoft: "#D5F0FF", deco: "dolphin", grass: "#69C87E" },
  },
  {
    id: 7,
    name: "Mango Mountain",
    tagline: "Sweet mangoes grow on the hilltops.",
    icon: "🥭",
    theme: { ...base, skyTop: "#CFF1DE", skyBottom: "#FFE3AE", seaTop: "#46D2BC", seaBottom: "#0C8FA0", accent: "#F27C2E", accentSoft: "#FFE3C1", deco: "mango", grass: "#48B36C" },
  },
  {
    id: 8,
    name: "Starlight Shore",
    tagline: "The stars make the sea twinkle.",
    icon: "✨",
    theme: { ...base, sand: "#FBE6C6", sandShade: "#EBC98F", skyTop: "#B6B9F5", skyBottom: "#FFD9C4", seaTop: "#56C8E8", seaBottom: "#3A62B8", accent: "#FFD35C", accentSoft: "#F3EAFF", deco: "stars", grass: "#59B79C" },
  },
  {
    id: 9,
    name: "Turtle Atoll",
    tagline: "Slow and steady wins the treasure!",
    icon: "🐢",
    theme: { ...base, sand: "#FFF1CE", skyTop: "#C3F2E4", skyBottom: "#FFF0C9", seaTop: "#54E0C5", seaBottom: "#1594A5", accent: "#3FBE8A", accentSoft: "#DDF7E7", deco: "turtle", grass: "#5CC47D" },
  },
  {
    id: 10,
    name: "Treasure Isle",
    tagline: "X marks the spot — the treasure is here!",
    icon: "💎",
    theme: { ...base, sand: "#FFE9A8", sandShade: "#F0C776", skyTop: "#FFE7B0", skyBottom: "#FFD1D6", seaTop: "#54D6CF", seaBottom: "#118CB8", accent: "#F5B51B", accentSoft: "#FFF1C0", deco: "treasure", grass: "#5CC06B" },
  },
];

export const ISLAND_COUNT = ISLANDS.length;
export const QUESTIONS_PER_ISLAND = 5;
