import {
  IRREGULAR_VERBS,
  ISLANDS,
  REGULAR_VERBS,
  type Verb,
} from "./data";

export type QuestionType = "choose" | "regular" | "fill" | "match" | "sort";

export interface MatchPair {
  present: string;
  past: string;
  tip: string;
}

export interface Question {
  id: string;
  type: QuestionType;
  title: string;
  instruction: string;
  verb: Verb;
  options: string[];
  pairs: MatchPair[];
  items: Verb[];
  correct: string;
  explanation: string;
}

export const QUESTION_META: Record<
  QuestionType,
  { label: string; icon: string; color: string; short: string }
> = {
  choose: { label: "Choose the Answer", icon: "🧭", color: "#2E86DE", short: "Pick the past form" },
  regular: { label: "Regular or Irregular?", icon: "⚖️", color: "#F28C28", short: "Sort the verb" },
  fill: { label: "Complete the Sentence", icon: "✍️", color: "#8E59D6", short: "Type the verb" },
  match: { label: "Verb Matching", icon: "🔗", color: "#159F7A", short: "Match the pairs" },
  sort: { label: "Treasure Sort", icon: "🧺", color: "#E1557B", short: "Drag & drop" },
};

export function shuffle<T>(arr: readonly T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

const pick = <T,>(arr: T[]) => arr[Math.floor(Math.random() * arr.length)];

/** Builds believable (but wrong) past forms for the multiple-choice question. */
function makeOptions(verb: Verb): string[] {
  const wrong = new Set<string>();
  wrong.add(verb.present);
  if (verb.irregular) {
    wrong.add(`${verb.present}ed`);
    const doubles = ["goed", "eated", "seed", "buyed", "taked", "haved", "maked", "drinked", "writed", "finded", "comed", "runned", "sleeped", "gived", "swimmed"];
    wrong.add(pick(doubles));
    wrong.add(pick(IRREGULAR_VERBS.filter((v) => v.past !== verb.past)).past);
  } else {
    wrong.add(`${verb.present}ed`);
    if (verb.present.endsWith("e")) wrong.add(`${verb.present}d`);
    if (verb.present.endsWith("y")) wrong.add(`${verb.present.slice(0, -1)}ied`);
    wrong.add(pick(REGULAR_VERBS.filter((v) => v.past !== verb.past)).past);
    wrong.add(pick(IRREGULAR_VERBS).past);
  }
  wrong.delete(verb.past);
  // "traveled" is a valid American spelling, so it must never appear as a distractor.
  if (verb.past === "travelled") wrong.delete("traveled");
  const distractors = shuffle([...wrong]).slice(0, 2);
  while (distractors.length < 2) {
    const extra = `${verb.present}ing`;
    if (!distractors.includes(extra)) distractors.push(extra);
  }
  return shuffle([verb.past, ...distractors]);
}

function buildQuestion(type: QuestionType, islandId: number, qNumber: number, verbs: Verb[]): Question {
  const base = { id: `i${islandId}-q${qNumber}-${type}`, type, verb: verbs[0] };
  if (type === "match") {
    const pairs = verbs.slice(0, 3).map((v) => ({ present: v.present, past: v.past, tip: v.tip }));
    return {
      ...base,
      title: "Match the pirate pairs",
      instruction: "Tap a present verb, then tap its past form to link them.",
      options: [],
      pairs,
      items: verbs.slice(0, 3),
      correct: "matched",
      explanation: pairs.map((p) => `${p.present} → ${p.past}`).join("  ·  "),
    };
  }
  if (type === "sort") {
    const items = shuffle(verbs.slice(0, 4));
    return {
      ...base,
      title: "Fill the treasure chests",
      instruction: "Pop each verb into the correct chest: Regular (-ed) or Irregular (changes).",
      options: [],
      pairs: [],
      items,
      correct: "sorted",
      explanation: items.map((v) => `${v.present} → ${v.past}`).join("  ·  "),
    };
  }
  if (type === "regular") {
    return {
      ...base,
      title: "Regular or irregular?",
      instruction: `The verb is “${verbs[0].present}”. Which treasure chest does it belong to?`,
      options: shuffle(["Regular", "Irregular"]),
      pairs: [],
      items: [],
      correct: verbs[0].irregular ? "Irregular" : "Regular",
      explanation: `${verbs[0].present} → ${verbs[0].past}. ${verbs[0].tip}`,
    };
  }
  if (type === "fill") {
    return {
      ...base,
      title: "Complete the sentence",
      instruction: "Write the missing past simple verb in the little box.",
      options: [],
      pairs: [],
      items: [],
      correct: verbs[0].past,
      explanation: `${verbs[0].present} → ${verbs[0].past}. ${verbs[0].tip}`,
    };
  }
  return {
    ...base,
    title: "Which one is the past?",
    instruction: `Choose the correct past simple form of “${verbs[0].present}”.`,
    options: makeOptions(verbs[0]),
    pairs: [],
    items: [],
    correct: verbs[0].past,
    explanation: `${verbs[0].present} → ${verbs[0].past}. ${verbs[0].tip}`,
  };
}

export interface IslandQuestions {
  islandId: number;
  questions: Question[];
}

/**
 * Every island gets exactly five questions — one of each format, in a random
 * order. Verbs are cycled so the whole voyage covers both verb families.
 */
export function generateVoyage(): IslandQuestions[] {
  const regularPool = shuffle(REGULAR_VERBS);
  const irregularPool = shuffle(IRREGULAR_VERBS);
  let regIndex = 0;
  let irrIndex = 0;
  const nextRegular = () => {
    const verb = regularPool[regIndex % regularPool.length];
    regIndex += 1;
    return verb;
  };
  const nextIrregular = () => {
    const verb = irregularPool[irrIndex % irregularPool.length];
    irrIndex += 1;
    return verb;
  };

  return ISLANDS.map((island, islandIndex) => {
    // Ten verb slots per island: 3 solo questions + 3 match + 4 sort.
    // Every island alternates between a regular-leaning and irregular-leaning deck.
    const regularCount = islandIndex % 2 === 0 ? 5 : 4;
    const irregularCount = 10 - regularCount;
    const regularDeck = Array.from({ length: regularCount }, nextRegular);
    const irregularDeck = Array.from({ length: irregularCount }, nextIrregular);

    // The sorting challenge always contains exactly two verbs of each family.
    const sortVerbs = shuffle([
      regularDeck.pop() as Verb,
      regularDeck.pop() as Verb,
      irregularDeck.pop() as Verb,
      irregularDeck.pop() as Verb,
    ]);

    // The matching challenge mixes both families too.
    const matchVerbs = shuffle([
      irregularDeck.pop() as Verb,
      irregularDeck.pop() as Verb,
      regularDeck.pop() as Verb,
    ]);

    const soloVerbs = shuffle([...regularDeck, ...irregularDeck]);

    const types: QuestionType[] = shuffle(["choose", "regular", "fill", "match", "sort"]);
    // Give every new sailor a quick, friendly win on the very first clue.
    if (islandIndex === 0) {
      const chooseIndex = types.indexOf("choose");
      [types[0], types[chooseIndex]] = [types[chooseIndex], types[0]];
    }
    const questions = types.map((type, index) => {
      if (type === "sort") return buildQuestion(type, island.id, index + 1, sortVerbs);
      if (type === "match") return buildQuestion(type, island.id, index + 1, matchVerbs);
      const verb = soloVerbs.pop() ?? nextRegular();
      return buildQuestion(type, island.id, index + 1, [verb]);
    });

    return { islandId: island.id, questions };
  });
}

export function normalizeAnswer(value: string): string {
  return value.trim().toLowerCase().replace(/\s+/g, " ");
}

export function isFillCorrect(answer: string, correct: string): boolean {
  const clean = normalizeAnswer(answer);
  if (clean === normalizeAnswer(correct)) return true;
  // Friendly spelling allowance for the two accepted British/American forms.
  if (correct === "travelled" && clean === "traveled") return true;
  return false;
}

export const PIRATE_PRAISE = [
  "Ahoy! Brilliant answer!",
  "You're a clever pirate!",
  "Great job, matey!",
  "Shiver me timbers — well done!",
  "Yo-ho-ho! That's correct!",
  "A golden answer, little pirate!",
  "The parrots are cheering for you!",
  "Smooth sailing, smart sailor!",
];

export const PIRATE_OOPS = [
  "Oops! Try again, little pirate!",
  "Nearly there, matey! Have another go.",
  "The treasure is close — try once more!",
  "Not quite! Your pirate brain can do it.",
  "A little wave — let's try again!",
];

export const randomPraise = () => pick(PIRATE_PRAISE);
export const randomOops = () => pick(PIRATE_OOPS);
