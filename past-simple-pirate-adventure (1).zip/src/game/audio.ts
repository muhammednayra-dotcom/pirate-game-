/* A tiny synthesized audio engine — no external sound files required. */

const NOTE: Record<string, number> = {
  C3: 130.81, D3: 146.83, E3: 164.81, F3: 174.61, G3: 196.0, A3: 220.0, B3: 246.94,
  C4: 261.63, D4: 293.66, E4: 329.63, F4: 349.23, G4: 392.0, A4: 440.0, B4: 493.88,
  C5: 523.25, D5: 587.33, E5: 659.25, F5: 698.46, G5: 783.99, A5: 880.0, C6: 1046.5,
  D6: 1174.66, E6: 1318.51, G6: 1567.98,
};

// A bouncy little sea-shanty melody in C major.
const MELODY: (string | null)[] = [
  "G4", "C5", "E5", "C5", "D5", "E5", "G5", null,
  "A5", "G5", "E5", "D5", "C5", "D5", "E5", null,
  "G4", "C5", "E5", "G5", "A5", "G5", "E5", null,
  "D5", "C5", "A4", "C5", "D5", null, "C5", null,
];
const BASS: (string | null)[] = ["C3", null, null, null, "G3", null, null, null, "A3", null, null, null, "F3", null, "G3", null];

class PirateAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private timer: number | null = null;
  private seagullTimer: number | null = null;
  private nextStepTime = 0;
  private step = 0;
  private active = false;
  muted = false;

  constructor() {
    try {
      this.muted = localStorage.getItem("psp-muted") === "1";
    } catch {
      this.muted = false;
    }
  }

  private build() {
    if (this.ctx) return this.ctx;
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    const ctx = new Ctor();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 0.85;
    this.master.connect(ctx.destination);
    this.musicBus = ctx.createGain();
    this.musicBus.gain.value = 0.2;
    this.musicBus.connect(this.master);
    this.sfxBus = ctx.createGain();
    this.sfxBus.gain.value = 0.55;
    this.sfxBus.connect(this.master);

    // Rolling ocean ambience built from filtered noise.
    const len = ctx.sampleRate * 3;
    const buffer = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < len; i += 1) data[i] = Math.random() * 2 - 1;
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    noise.loop = true;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 460;
    filter.Q.value = 0.7;
    const gain = ctx.createGain();
    gain.gain.value = 0.05;
    noise.connect(filter).connect(gain).connect(this.master);
    noise.start();

    // Slow swell in the waves.
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.11;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 0.022;
    lfo.connect(lfoGain).connect(gain.gain);
    lfo.start();

    document.addEventListener("visibilitychange", () => {
      if (!this.ctx) return;
      if (document.hidden) void this.ctx.suspend();
      else if (this.active) void this.ctx.resume();
    });
    return ctx;
  }

  start() {
    const ctx = this.build();
    if (!ctx) return;
    this.active = true;
    void ctx.resume();
    if (this.timer === null) {
      this.nextStepTime = ctx.currentTime + 0.15;
      this.timer = window.setInterval(() => this.schedule(), 120);
      if (this.seagullTimer === null) {
        this.seagullTimer = window.setInterval(() => {
          if (Math.random() > 0.55) this.gull();
        }, 16000);
      }
    }
  }

  private schedule() {
    const ctx = this.ctx;
    if (!ctx || !this.musicBus || this.muted) return;
    // If the tab was hidden or the music was muted for a while, don't queue
    // hundreds of missed notes at once.
    if (this.nextStepTime < ctx.currentTime) this.nextStepTime = ctx.currentTime + 0.08;
    const stepDur = 0.24;
    while (this.nextStepTime < ctx.currentTime + 0.5) {
      const note = MELODY[this.step % MELODY.length];
      if (note) this.pluck(NOTE[note], this.nextStepTime, stepDur * 1.5, 0.16, "triangle", this.musicBus);
      if (note && this.step % 4 === 0) this.pluck(NOTE[note] * 2, this.nextStepTime, 0.16, 0.03, "sine", this.musicBus);
      const bass = BASS[this.step % BASS.length];
      if (bass) this.pluck(NOTE[bass], this.nextStepTime, 0.4, 0.22, "sine", this.musicBus);
      if (this.step % 4 === 0) this.shaker(this.nextStepTime);
      this.nextStepTime += stepDur;
      this.step += 1;
    }
  }

  private pluck(freq: number, when: number, dur: number, peak: number, type: OscillatorType, bus: GainNode | null) {
    const ctx = this.ctx;
    if (!ctx || !bus) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, when);
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(peak, when + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    osc.connect(gain).connect(bus);
    osc.start(when);
    osc.stop(when + dur + 0.05);
  }

  private shaker(when: number) {
    const ctx = this.ctx;
    if (!ctx || !this.musicBus) return;
    const buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.05), ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i += 1) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const high = ctx.createBiquadFilter();
    high.type = "highpass";
    high.frequency.value = 5000;
    const gain = ctx.createGain();
    gain.gain.value = 0.05;
    src.connect(high).connect(gain).connect(this.musicBus);
    src.start(when);
  }

  private sfx(notes: number[], type: OscillatorType = "triangle", spacing = 0.09, peak = 0.25, dur = 0.3) {
    const ctx = this.build();
    if (!ctx || this.muted || !this.sfxBus) return;
    if (ctx.state === "suspended") void ctx.resume();
    const now = ctx.currentTime + 0.01;
    notes.forEach((freq, index) => {
      if (!this.sfxBus) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, now + index * spacing);
      gain.gain.setValueAtTime(0.0001, now + index * spacing);
      gain.gain.exponentialRampToValueAtTime(peak, now + index * spacing + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + index * spacing + dur);
      osc.connect(gain).connect(this.sfxBus);
      osc.start(now + index * spacing);
      osc.stop(now + index * spacing + dur + 0.05);
    });
  }

  private gull() {
    const ctx = this.build();
    if (!ctx || this.muted || !this.sfxBus) return;
    const now = ctx.currentTime + 0.05;
    [0, 0.18].forEach((offset, i) => {
      if (!this.sfxBus) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(1500 - i * 150, now + offset);
      osc.frequency.exponentialRampToValueAtTime(900, now + offset + 0.22);
      gain.gain.setValueAtTime(0.0001, now + offset);
      gain.gain.exponentialRampToValueAtTime(0.07, now + offset + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + offset + 0.25);
      osc.connect(gain).connect(this.sfxBus);
      osc.start(now + offset);
      osc.stop(now + offset + 0.3);
    });
  }

  setMuted(value: boolean) {
    this.muted = value;
    try {
      localStorage.setItem("psp-muted", value ? "1" : "0");
    } catch {
      /* ignore */
    }
    if (this.ctx && this.master) {
      this.master.gain.cancelScheduledValues(this.ctx.currentTime);
      this.master.gain.linearRampToValueAtTime(value ? 0 : 0.85, this.ctx.currentTime + 0.2);
    }
    if (!value) this.start();
  }

  click() { this.sfx([NOTE.E5, NOTE.G5], "sine", 0.05, 0.16, 0.16); }
  coin() { this.sfx([NOTE.C6, NOTE.G6], "sine", 0.055, 0.2, 0.22); }
  correct() { this.sfx([NOTE.C5, NOTE.E5, NOTE.G5, NOTE.C6], "triangle", 0.075, 0.24, 0.32); }
  wrong() { this.sfx([NOTE.A3, NOTE.F3], "sine", 0.12, 0.18, 0.28); }
  match() { this.sfx([NOTE.E5, NOTE.G5, NOTE.E6], "triangle", 0.05, 0.18, 0.2); }
  key() { this.sfx([NOTE.C5, NOTE.E5, NOTE.G5, NOTE.C6, NOTE.E6, NOTE.G6], "triangle", 0.075, 0.22, 0.45); }
  sail() {
    const ctx = this.build();
    if (!ctx || this.muted || !this.sfxBus) return;
    const len = ctx.sampleRate * 1.6;
    const buffer = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < len; i += 1) data[i] = (Math.random() * 2 - 1) * Math.sin((i / len) * Math.PI);
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.setValueAtTime(350, ctx.currentTime);
    filter.frequency.linearRampToValueAtTime(1400, ctx.currentTime + 1.2);
    filter.Q.value = 0.8;
    const gain = ctx.createGain();
    gain.gain.value = 0.22;
    src.connect(filter).connect(gain).connect(this.sfxBus);
    src.start();
  }
  fanfare() { this.sfx([NOTE.G4, NOTE.C5, NOTE.E5, NOTE.G5, NOTE.C6, NOTE.E6, NOTE.G6], "triangle", 0.11, 0.24, 0.55); }
  chest() { this.sfx([NOTE.C3, NOTE.E3, NOTE.G3, NOTE.C5, NOTE.E5, NOTE.G5, NOTE.C6], "triangle", 0.1, 0.28, 0.6); }
}

export const audio = new PirateAudio();
